#!/bin/bash

ufw enable

# set users in users
# format:
# user1:sudo
# OR
# user2:nosudo

calcnondef() {
cat /etc/passwd > passwd
sed -i '/root:x/d' passwd
sed -i '/daemon:x/d' passwd
sed -i '/bin:x/d' passwd
sed -i '/sys:x/d' passwd
sed -i '/sync:x/d' passwd
sed -i '/games:x/d' passwd
sed -i '/man:x/d' passwd
sed -i '/lp:x/d' passwd
sed -i '/mail:x/d' passwd
sed -i '/news:x/d' passwd
sed -i '/uucp:x/d' passwd
sed -i '/proxy:x/d' passwd
sed -i '/www-data:x/d' passwd
sed -i '/backup:x/d' passwd
sed -i '/list:x/d' passwd
sed -i '/irc:x/d' passwd
sed -i '/gnats:x/d' passwd
sed -i '/nobody:x/d' passwd
sed -i '/libuuid:x/d' passwd
sed -i '/syslog:x/d' passwd
sed -i '/messagebus:x/d' passwd
sed -i '/usbmux:x/d' passwd
sed -i '/dnsmasq:x/d' passwd
sed -i '/avahi-autoipd:x/d' passwd
sed -i '/kernoops:x/d' passwd
sed -i '/rtkit:x/d' passwd
sed -i '/saned:x/d' passwd
sed -i '/whoopsie:x/d' passwd
sed -i '/speech-dispatcher:x/d' passwd
sed -i '/avahi:x/d' passwd
sed -i '/lightdm:x/d' passwd
sed -i '/colord:x/d' passwd
sed -i '/hplip:x/d' passwd
sed -i '/pulse:x/d' passwd
}

clear


echo

echo "Now users will be configured."

cat /etc/passwd | cut -f1 -d":" > userspwd; for i in $(cat userspwd); do echo $i:CyberSec123! | chpasswd; done
for user in $(cat users | cut -f1 -d ":"); do useradd $user; usermod -s /bin/bash $user; done
for sudoer in $(grep sudo users | cut -f1 -d ":"); do adduser $sudoer sudo; done
for nonsudoer in $(grep nosudo users | cut -f1 -d ":"); do deluser $nonsudoer sudo; done
calcnondef
for userses in $(cat users); do sed -i "/$userses/d/" passwd; userdel -f $(cat passwd); done

echo "allow-guest=false" >> /usr/share/lightdm/lightdm.conf.d/50-unity-greeter.conf
echo "greeter-hide-users=true" >> /usr/share/lightdm/lightdm.conf.d/50-unity-greeter.conf
echo "greeter-show-manual-login=true" >> /usr/share/lightdm/lightdm.conf.d/50-unity-greeter.conf

###################################################################################################################

# PKGS
cp -f data/initial-status.gz /var/log/installer/initial-status.gz
echo "These are the manually installed packages:"
comm -23 <(apt-mark showmanual | sort -u) <(gzip -dc /var/log/installer/initial-status.gz | sed -n 's/^Package: //p' | sort -u)
echo "Take notes"
echo "Adding apt-fast..."

sudo add-apt-repository ppa:apt-fast/stable
sudo apt-get update
sudo apt-get -y install apt-fast

for instpkg in fail2ban ansible aide debsecan debsums lynis auditd audispd-plugins logrotate clamav aide chkrootkit rkhunter libpam-cracklib apparmor gufw psad ufw iptables iptables-persistent nmap; do apt-fast -y install $instpkg; done

for delpkg in xinetd *samba* telnet* transmission *torrent* ; do apt-fast -y purge $delpkg; done

apt-fast -y purge acccheck
apt-fast -y purge ace-voip
apt-fast -y purge amap
apt-fast -y purge apt2
apt-fast -y purge arp-scan
apt-fast -y purge automater
apt-fast -y purge bing-ip2hosts
apt-fast -y purge braa
apt-fast -y purge casefile
apt-fast -y purge cdpsnarf
apt-fast -y purge cisco-torch
apt-fast -y purge cookie cadger
apt-fast -y purge copy-router-config
apt-fast -y purge dmitry
apt-fast -y purge dnmap
apt-fast -y purge dnsenum
apt-fast -y purge dnsmap
apt-fast -y purge dnsrecon
apt-fast -y purge dnstracer
apt-fast -y purge dnswalk
apt-fast -y purge dotdotpwn
apt-fast -y purge enum4linux
apt-fast -y purge enumiax
apt-fast -y purge eyewitness
apt-fast -y purge faraday
apt-fast -y purge fierce
apt-fast -y purge firewalk
apt-fast -y purge fragroute
apt-fast -y purge fragrouter
apt-fast -y purge ghost phisher
apt-fast -y purge golismero
apt-fast -y purge goofile
apt-fast -y purge hping3
apt-fast -y purge ident-user-enum
apt-fast -y purge inspy
apt-fast -y purge intrace
apt-fast -y purge ismtp
apt-fast -y purge lbd
apt-fast -y purge maltego teeth
apt-fast -y purge masscan
apt-fast -y purge metagoofil
apt-fast -y purge miranda
apt-fast -y purge nbtscan-unixwiz
apt-fast -y purge nikto
apt-fast -y purge nmap
apt-fast -y purge ntop
apt-fast -y purge osrframework
apt-fast -y purge p0f
apt-fast -y purge parsero
apt-fast -y purge recon-ng
apt-fast -y purge set
apt-fast -y purge smbmap
apt-fast -y purge smtp-user-enum
apt-fast -y purge snmp-check
apt-fast -y purge sparta
apt-fast -y purge sslcaudit
apt-fast -y purge sslsplit
apt-fast -y purge sslstrip
apt-fast -y purge sslyze
apt-fast -y purge sublist3r
apt-fast -y purge thc-ipv6
apt-fast -y purge theharvester
apt-fast -y purge tlssled
apt-fast -y purge twofi
apt-fast -y purge unicornscan
apt-fast -y purge urlcrazy
apt-fast -y purge wireshark
apt-fast -y purge wol-e
apt-fast -y purge xplico 
apt-fast -y purge bbqsql
apt-fast -y purge bed
apt-fast -y purge cisco-auditing-tool
apt-fast -y purge cisco-global-exploiter
apt-fast -y purge cisco-ocs
apt-fast -y purge cisco-torch
apt-fast -y purge copy-router-config
apt-fast -y purge dbpwaudit
apt-fast -y purge doona
apt-fast -y purge dotdotpwn
apt-fast -y purge hexorbase
apt-fast -y purge inguma
apt-fast -y purge jsql injection
apt-fast -y purge lynis
apt-fast -y purge nmap
apt-fast -y purge ohrwurm
apt-fast -y purge openvas
apt-fast -y purge oscanner
apt-fast -y purge powerfuzzer
apt-fast -y purge sfuzz
apt-fast -y purge sidguesser
apt-fast -y purge siparmyknife
apt-fast -y purge sqlmap
apt-fast -y purge sqlninja
apt-fast -y purge sqlsus
apt-fast -y purge thc-ipv6
apt-fast -y purge tnscmd10g
apt-fast -y purge unix-privesc-check
apt-fast -y purge yersinia
apt-fast -y purge armitage
apt-fast -y purge backdoor factory
apt-fast -y purge beef
apt-fast -y purge cisco-auditing-tool
apt-fast -y purge cisco-global-exploiter
apt-fast -y purge cisco-ocs
apt-fast -y purge cisco-torch
apt-fast -y purge commix
apt-fast -y purge crackle
apt-fast -y purge exploitdb
apt-fast -y purge jboss-autopwn
apt-fast -y purge linux exploit suggester
apt-fast -y purge maltego teeth
apt-fast -y purge metasploit framework
apt-fast -y purge msfpc
apt-fast -y purge routersploit
apt-fast -y purge set
apt-fast -y purge shellnoob
apt-fast -y purge sqlmap
apt-fast -y purge thc-ipv6
apt-fast -y purge yersinia
apt-fast -y purge airbase-ng
apt-fast -y purge aircrack-ng
apt-fast -y purge airdecap-ng and airdecloak-ng
apt-fast -y purge aireplay-ng
apt-fast -y purge airmon-ng
apt-fast -y purge airodump-ng
apt-fast -y purge airodump-ng-oui-update
apt-fast -y purge airolib-ng
apt-fast -y purge airserv-ng
apt-fast -y purge airtun-ng
apt-fast -y purge asleap
apt-fast -y purge besside-ng
apt-fast -y purge bluelog
apt-fast -y purge bluemaho
apt-fast -y purge bluepot
apt-fast -y purge blueranger
apt-fast -y purge bluesnarfer
apt-fast -y purge bully
apt-fast -y purge cowpatty
apt-fast -y purge crackle
apt-fast -y purge eapmd5pass
apt-fast -y purge easside-ng
apt-fast -y purge fern wifi cracker
apt-fast -y purge freeradius-wpe
apt-fast -y purge ghost phisher
apt-fast -y purge giskismet
apt-fast -y purge gqrx
apt-fast -y purge gr-scan
apt-fast -y purge hostapd-wpe
apt-fast -y purge ivstools
apt-fast -y purge kalibrate-rtl
apt-fast -y purge killerbee
apt-fast -y purge kismet
apt-fast -y purge makeivs-ng
apt-fast -y purge mdk3
apt-fast -y purge mfcuk
apt-fast -y purge mfoc
apt-fast -y purge mfterm
apt-fast -y purge multimon-ng
apt-fast -y purge packetforge-ng
apt-fast -y purge pixiewps
apt-fast -y purge pyrit
apt-fast -y purge reaver
apt-fast -y purge redfang
apt-fast -y purge rtlsdr scanner
apt-fast -y purge spooftooph
apt-fast -y purge tkiptun-ng
apt-fast -y purge wesside-ng
apt-fast -y purge wifi honey
apt-fast -y purge wifiphisher
apt-fast -y purge wifitap
apt-fast -y purge wifite
apt-fast -y purge wpaclean
apt-fast -y purge binwalk
apt-fast -y purge bulk-extractor
apt-fast -y purge capstone
apt-fast -y purge chntpw
apt-fast -y purge cuckoo
apt-fast -y purge dc3dd
apt-fast -y purge ddrescue
apt-fast -y purge dff
apt-fast -y purge distorm3
apt-fast -y purge dumpzilla
apt-fast -y purge extundelete
apt-fast -y purge foremost
apt-fast -y purge galleta
apt-fast -y purge guymager
apt-fast -y purge iphone backup analyzer
apt-fast -y purge p0f
apt-fast -y purge pdf-parser
apt-fast -y purge pdfid
apt-fast -y purge pdgmail
apt-fast -y purge peepdf
apt-fast -y purge regripper
apt-fast -y purge volatility
apt-fast -y purge xplico
apt-fast -y purge apache-users
apt-fast -y purge arachni
apt-fast -y purge bbqsql
apt-fast -y purge blindelephant
apt-fast -y purge burp suite
apt-fast -y purge cutycapt
apt-fast -y purge davtest
apt-fast -y purge deblaze
apt-fast -y purge dirb
apt-fast -y purge dirbuster
apt-fast -y purge fimap
apt-fast -y purge funkload
apt-fast -y purge gobuster
apt-fast -y purge grabber
apt-fast -y purge hurl
apt-fast -y purge jboss-autopwn
apt-fast -y purge joomscan
apt-fast -y purge jsql injection
apt-fast -y purge maltego teeth
apt-fast -y purge nikto
apt-fast -y purge padbuster
apt-fast -y purge paros
apt-fast -y purge parsero
apt-fast -y purge plecost
apt-fast -y purge powerfuzzer
apt-fast -y purge proxystrike
apt-fast -y purge recon-ng
apt-fast -y purge skipfish
apt-fast -y purge sqlmap
apt-fast -y purge sqlninja
apt-fast -y purge sqlsus
apt-fast -y purge ua-tester
apt-fast -y purge uniscan
apt-fast -y purge vega
apt-fast -y purge w3af
apt-fast -y purge webscarab
apt-fast -y purge webshag
apt-fast -y purge webslayer
apt-fast -y purge websploit
apt-fast -y purge wfuzz
apt-fast -y purge whatweb
apt-fast -y purge wpscan
apt-fast -y purge xsser
apt-fast -y purge zaproxy
apt-fast -y purge dhcpig
apt-fast -y purge funkload
apt-fast -y purge iaxflood
apt-fast -y purge inundator
apt-fast -y purge inviteflood
apt-fast -y purge ipv6-toolkit
apt-fast -y purge mdk3
apt-fast -y purge reaver
apt-fast -y purge rtpflood
apt-fast -y purge slowhttptest
apt-fast -y purge t50
apt-fast -y purge termineter
apt-fast -y purge thc-ipv6
apt-fast -y purge thc-ssl-dos
apt-fast -y purge burp suite
apt-fast -y purge dnschef
apt-fast -y purge fiked
apt-fast -y purge hamster-sidejack
apt-fast -y purge hexinject
apt-fast -y purge iaxflood
apt-fast -y purge inviteflood
apt-fast -y purge ismtp
apt-fast -y purge isr-evilgrade
apt-fast -y purge mitmproxy
apt-fast -y purge ohrwurm
apt-fast -y purge protos-sip
apt-fast -y purge rebind
apt-fast -y purge responder
apt-fast -y purge rtpbreak
apt-fast -y purge rtpinsertsound
apt-fast -y purge rtpmixsound
apt-fast -y purge sctpscan
apt-fast -y purge siparmyknife
apt-fast -y purge sipp
apt-fast -y purge sipvicious
apt-fast -y purge sniffjoke
apt-fast -y purge sslsplit
apt-fast -y purge sslstrip
apt-fast -y purge thc-ipv6
apt-fast -y purge voiphopper
apt-fast -y purge webscarab
apt-fast -y purge wifi honey
apt-fast -y purge wireshark
apt-fast -y purge xspy
apt-fast -y purge yersinia
apt-fast -y purge zaproxy
apt-fast -y purge acccheck
apt-fast -y purge brutespray
apt-fast -y purge burp suite
apt-fast -y purge cewl
apt-fast -y purge chntpw
apt-fast -y purge cisco-auditing-tool
apt-fast -y purge cmospwd
apt-fast -y purge creddump
apt-fast -y purge crowbar
apt-fast -y purge crunch
apt-fast -y purge dbpwaudit
apt-fast -y purge findmyhash
apt-fast -y purge gpp-decrypt
apt-fast -y purge hash-identifier
apt-fast -y purge hashcat
apt-fast -y purge hexorbase
apt-fast -y purge thc-hydra
apt-fast -y purge john the ripper
apt-fast -y purge johnny
apt-fast -y purge keimpx
apt-fast -y purge maltego teeth
apt-fast -y purge maskprocessor
apt-fast -y purge multiforcer
apt-fast -y purge ncrack
apt-fast -y purge oclgausscrack
apt-fast -y purge ophcrack
apt-fast -y purge pack
apt-fast -y purge patator
apt-fast -y purge phrasendrescher
apt-fast -y purge polenum
apt-fast -y purge rainbowcrack
apt-fast -y purge rcracki-mt
apt-fast -y purge rsmangler
apt-fast -y purge seclists
apt-fast -y purge sqldict
apt-fast -y purge statsprocessor
apt-fast -y purge thc-pptp-bruter
apt-fast -y purge truecrack
apt-fast -y purge webscarab
apt-fast -y purge wordlists
apt-fast -y purge zaproxy
apt-fast -y purge cryptcat
apt-fast -y purge cymothoa
apt-fast -y purge dbd
apt-fast -y purge dns2tcp
apt-fast -y purge http-tunnel
apt-fast -y purge httptunnel
apt-fast -y purge intersect
apt-fast -y purge nishang
apt-fast -y purge polenum
apt-fast -y purge powersploit
apt-fast -y purge pwnat
apt-fast -y purge ridenum
apt-fast -y purge sbd
apt-fast -y purge shellter
apt-fast -y purge u3-pwn
apt-fast -y purge webshells
apt-fast -y purge weevely
apt-fast -y purge winexe
apt-fast -y purge android-sdk
apt-fast -y purge apktool
apt-fast -y purge arduino
apt-fast -y purge dex2jar
apt-fast -y purge sakis3g
apt-fast -y purge smali
apt-fast -y purge apktool
apt-fast -y purge dex2jar
apt-fast -y purge distorm3
apt-fast -y purge edb-debugger
apt-fast -y purge jad
apt-fast -y purge javasnoop
apt-fast -y purge jd-gui
apt-fast -y purge ollydbg
apt-fast -y purge smali
apt-fast -y purge valgrind
apt-fast -y purge yara
apt-fast -y purge casefile
apt-fast -y purge cherrytree
apt-fast -y purge cutycapt
apt-fast -y purge dradis
apt-fast -y purge magictree
apt-fast -y purge metagoofil
apt-fast -y purge nipper-ng
apt-fast -y purge pipal
apt-fast -y purge rdpy

apt-fast -y update
apt-fast -y dist-upgrade

###################################################################################################################

# PASSWORD SECURITY CONFIGURATION

cp -f data/login.defs /etc/login.defs
cp -f data/access.conf /etc/security/access.conf
cp -f data/shells /etc/shells
cp -f data/.profile ~/.profile
cp -f data/.profile /etc/profile
echo "umask 077" > /etc/csh.cshrc
echo "umask 022" >> /lib/lsb/init-functions
cp -f data/limits.conf
rm -rf /etc/security/console.perms
echo "Null Passwords have been allowed in these files:"
echo
grep -ir "nullok" /etc
echo
echo 'Configuring PAM!'
cp -Rf /etc/pam.d data/pam.d-img
cp -Rf data/pam.d /etc/pam.d
read -p "Did you get any points? (y/n) " pampoints

if [ "$pampoints" = "y" ]; then
  echo "Take note! After that, select the y option to remove the PAM configurations, and re-add them after the script"
  # aDD CLicK EnTeR to CONtinUe
fi

echo "Checking sudo config stuff now..."
sudo egrep -i '(nopasswd|!authenticate)' /etc/sudoers /etc/sudoers.d/*
echo "If there was an output, please note it down and FIX IT dumy pugy"

echo "Configure Secure Banner Messages/Login Configurations"
cp -f data/01-banner-message /etc/dconf/db/local.d/01-banner-message
cp -f data/issue /etc/issue
cp -f data/issue /etc/issue.net
cp -f data/issue /etc/motd
gsettings set org.gnome.desktop.lock-enabled true
touch /etc/profile.d/autologout.sh
cp -f data/autologout.sh /etc/profile.d/autologout.sh
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type int --set /apps/gnome-screensaver/idle_delay 15
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gnome-screensaver/idle_activation_enabled true
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gnome-screensaver/lock_enabled true
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gdm/simple-greeter/banner_message_enable true
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gdm/simple-greeter/disable_user_list true
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type string --set /apps/gnome-screensaver/mode blank-only
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type string --set /apps/gnome_settings_daemon/keybindings/screensaver "<Control><Alt>l"
gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type string --set /apps/gdm/simple-greeter/banner_message_text "I've read & consent to terms in IS user agreem't."

###########################################################################################################################

echo "Check Listening Ports/Services…"
sudo netstat -plnt
nmap -v -sT localhost
ps -aux | grep "nc"
service cron restart
killall -9 nc
sudo systemctl stop autofs
sudo systemctl enable apparmor.service
sudo systemctl start apparmor.service
echo "InitiallyPowered = False" > /etc/bluetooth/main.conf
service --status-all
sudo initctl list | grep running

##########################################################################################################################

echo "Setting Firewall rules…"
echo "IPv6=no" >> /etc/default/ufw
cp -f data/before.rules /etc/ufw/before.rules

iptables -A FORWARD -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s -j ACCEPT

ip6tables -A FORWARD -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s -j ACCEPT

iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -p icmp -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 22 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 53 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 53 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 69 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 69 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 88 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 88 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 123 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 123 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 389 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 389 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 464 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 464 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 514 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 514 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 636 -j ACCEPT
iptables -A INPUT -m state --state NEW -m udp -p udp --dport 636 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 2049 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 3260 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 8080 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 8443 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --match multiport --dports 5634:6166 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --match multiport --dports 8006:8009 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 16514 -s 192.168.0.0/24 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --match multiport --dports 49152:49216 -s 192.168.0.0/24 -j ACCEPT
iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 54321 -s 192.168.0.0/24 -j ACCEPT
iptables -A INPUT -p ICMP --icmp-type timestamp-request -j DROP
iptables -A INPUT -p ICMP --icmp-type timestamp-reply -j DROP
iptables -A INPUT -j REJECT --reject-with icmp-host-prohibited
iptables -A FORWARD -j REJECT --reject-with icmp-host-prohibited

ip6tables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
ip6tables -A INPUT -i lo -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 22 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 53 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 53 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 69 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 69 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 80 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 88 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 88 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 123 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 123 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 389 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 389 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 443 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 464 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 464 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 514 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 514 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 636 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m udp -p udp --dport 636 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 2049 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 3260 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 8080 -j ACCEPT
ip6tables -A INPUT -m state --state NEW -m tcp -p tcp --dport 8443 -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 128 -m limit --limit 15/sec -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 129 -m limit --limit 15/sec -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 133 -m hl --hl-eq 255 -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 134 -m hl --hl-eq 255 -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 135 -m hl --hl-eq 255 -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 136 -m hl --hl-eq 255 -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp --icmpv6-type 137 -m hl --hl-eq 255 -j ACCEPT
ip6tables -A INPUT -p ipv6-icmp -j LOG --log-prefix
ip6tables -A INPUT -p ipv6 -j DROP

##########################################################################################################################

echo "Securing Console"
echo tty1 > /etc/securetty

#########################################################################################################################

echo "Securing eff-stab…"

dd if=/dev/zero of=/usr/tmpDISK bs=1024 count=2048000
mkdir /tmpbackup
cp -Rpf /tmp /tmpbackup
mount -t tmpfs -o loop,noexec,nosuid,rw /usr/tmpDISK /tmp
chmod 1777 /tmp
cp -Rpf /tmpbackup/* /tmp/
rm -rf /tmpbackup
echo "/usr/tmpDISK  /tmp    tmpfs   loop,nosuid,nodev,noexec,rw  0 0" >> /etc/fstab
sudo mount -o remount /tmp
rm -rf /var/tmp
ln -s /tmp /var/tmp

########################################################################################################################

chmod -R g-wx,o-rwx /var/log/*
chown root:root /etc/ssh/sshd_config
chmod og-rwx /etc/ssh/sshd_config
chown root:root /etc/passwd
chmod 644 /etc/passwd
chown root:shadow /etc/shadow
chmod o-rwx,g-wx /etc/shadow
chown root:root /etc/group
chmod 644 /etc/group
chown root:shadow /etc/gshadow
chmod o-rwx,g-rw /etc/gshadow
chown root:root /etc/passwd-
chmod 600 /etc/passwd-
chown root:root /etc/shadow-
chmod 600 /etc/shadow-
chown root:root /etc/group-
chmod 600 /etc/group-
chown root:root /etc/gshadow-
chmod 600 /etc/gshadow-
chmod 700 /bin/su
#ADD BASICALLY EVERYTHING ELSE

#####################################################################################################################
function fs_disable {
  local FS
  FS="appletalk sctp dccp ddcp_ipv4 dccp_ipv6 rds tipc cramfs freevxfs jffs2 hfs hfsplus squashfs udf vfat"

  log_info "Disabling filesystems ${FS[@]}"
  for disable in $FS; do
      echo "install $disable /bin/true" >> "/etc/modprobe.d/${disable}.conf"
  done
}

echo "install usb-storage /bin/true" >> /etc/modprobe.d/usb-storage.conf
echo "install uas /bin/true" >> /etc/modprobe.d/usb-storage.conf
echo "install net-pf-31 /bin/true" >> /etc/modprobe.d/bluetooth.conf
echo "install bluetooth /bin/true" >> /etc/modprobe.d/bluetooth.conf
echo "install appletalk /bin/true" >> /etc/modprobe.conf
echo "install sctp /bin/true" >> /etc/modprobe.conf
echo "install dccp /bin/true" >> /etc/modprobe.conf 
echo "install dccp_ipv4 /bin/true" >> /etc/modprobe.conf 
echo "install dccp_ipv6 /bin/true" >> /etc/modprobe.conf
echo "install rds /bin/true" >> /etc/modprobe.conf 
echo "install tipc /bin/true" >> /etc/modprobe.conf

####################################################################################################################

./stig.sh

##################################################################################################################

#aide
echo "SILENTREPORTS=no" >> /etc/default/aide
echo "MAILTO=root" >> /etc/default/aide
echo "/usr/sbin/auditctl p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/auditd p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/ausearch p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/aureport p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/autrace p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/audispd p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/augenrules p+i+n+u+g+s+b+acl+xattr+sha512" >> /etc/aide/aide.conf

sudo aideinit
mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db
sudo aide --init
echo "05 4 * * * root /usr/sbin/aide --check" >> /etc/crontab 

#psad
echo "ENABLE_AUTO_IDS Y" >> /etc/psad/psad.conf
sudo iptables -A INPUT -j LOG
sudo iptables -A FORWARD -j LOG
sudo ip6tables -A INPUT -j LOG
sudo ip6tables -A FORWARD -j LOG
sudo iptables -P INPUT DROP
sudo ip6tables -P INPUT DROP
sudo psad -R
sudo psad --sig-update
sudo psad -H
echo ":FORWARD DROP [0:0]" >> /etc/sysconfig/iptables

#ansible
useradd ansibleadmin
usermod -aG sudo ansibleadmin
echo "defaults !requiretty
ansibleadmin ALL = (ALL) NOPASSWD: ALL" >> /etc/sudoers.d/ansible

#apt
echo "Unattended-Upgrade::Remove-Unused-Dependencies "true";" >> /etc/apt/apt.conf.d/50unattended-upgrades

#fail2ban

sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
echo "[ssh]
enabled = true
port = 22
filter = sshd
logpath = /var/log/auth.log
maxretry = 2
[ssh-ddos]
enabled = true
port = your port number or ssh
filter = sshd-ddos
logpath = /var/log/auth.log
maxretry = 2" >> /etc/fail2ban/jail.local

chmod 0640 /etc/audit/auditd.conf && chown root /etc/audit/auditd.conf && chgrp root /etc/audit/auditd.conf && chmod go-w /etc/audit/auditd.conf

echo "Services have been secured"

##################################################################################################################

# IT's SYSFILE SEC BOYS

echo 'APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";' > /etc/apt/apt.conf.d/20auto-upgrades

echo 'APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";' > /etc/apt/apt.conf.d/10periodic

cp -f data/useradd /etc/default/useradd
cp -f data/ntp.conf /etc/ntp.conf

##################################################################################################################

apache() {
    echo "Run JShielder!"
    cat data/apache-extra >> /etc/apache2/apache2.conf
    echo "apache2: ALL" >> /etc/hosts.allow
    # Honor Cipher Order
    # SSL Disable
}

mysql() {
    echo "Run JShielder!"    
    cat data/mysql-extra >> /etc/mysql/my.cnf
}

php() {
    echo "Run JShielder!"
}

ssh() {
    cp -f data/sshd_config /etc/ssh/sshd_config
    echo "sshd: ALL" >> /etc/hosts.allow
    find / -iname "*.equiv" -delete
    find / -iname "*.rhosts" -delete 
    find / -iname "*.perms" -delete  
    cd ~/.ssh
    ssh-keygen -t rsa
    scp -P 222 ~/.ssh/id_dsa.pub
    root@localhost:~/.ssh
}

vsftpd() {
    cp -f data/vsftpd.conf /etc/vsftpd.conf
    echo "vsftpd: ALL" >> /etc/hosts.allow
    iptables -I INPUT -p tcp --dport 64000:65535 -j ACCEPT
    ufw allow 22/tcp
}

samba() {
    cp -f
}