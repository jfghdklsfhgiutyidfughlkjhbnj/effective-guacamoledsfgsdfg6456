# Ubuntu Qual Round 2 Script!

ufw enable

# set users in users
# format:
# user1:sudo
# OR
# user2:nosudo

calcnondef() {
cat /etc/passwd > passwd
sed -i '/root/d' passwd
sed -i '/daemon/d' passwd
sed -i '/bin/d' passwd
sed -i '/sys/d' passwd
sed -i '/sync/d' passwd
sed -i '/games/d' passwd
sed -i '/man/d' passwd
sed -i '/lp/d' passwd
sed -i '/mail/d' passwd
sed -i '/news/d' passwd
sed -i '/uucp/d' passwd
sed -i '/proxy/d' passwd
sed -i '/www-data/d' passwd
sed -i '/backup/d' passwd
sed -i '/list/d' passwd
sed -i '/irc/d' passwd
sed -i '/gnats/d' passwd
sed -i '/nobody/d' passwd
sed -i '/libuuid/d' passwd
sed -i '/syslog/d' passwd
sed -i '/messagebus/d' passwd
sed -i '/usbmux/d' passwd
sed -i '/dnsmasq/d' passwd
sed -i '/avahi-autoipd/d' passwd
sed -i '/kernoops/d' passwd
sed -i '/rtkit/d' passwd
sed -i '/saned/d' passwd
sed -i '/whoopsie/d' passwd
sed -i '/speech-dispatcher/d' passwd
sed -i '/avahi/d' passwd
sed -i '/lightdm/d' passwd
sed -i '/colord/d' passwd
sed -i '/hplip/d' passwd
sed -i '/pulse/d' passwd
}

clear


echo

echo "Now users will be configured."

for user in $(cat users | cut -f1 -d ":"); do useradd $user; usermod -s /bin/bash $user; done
for sudoer in $(grep sudo users | cut -f1 -d ":"); do adduser $sudoer sudo; done
for nonsudoer in $(grep nosudo users | cut -f1 -d ":"); do deluser $nonsudoer sudo; done
calcnondef
for userses in $(cat users); do sed -i "/$userses/d/" passwd; userdel -f $(cat passwd); done
cat /etc/passwd | cut -f1 -d":" > userspwd; for i in $(cat userspwd); do echo $i:CyberSec123! | chpasswd; done

echo "allow-guest=false" >> /usr/share/lightdm/lightdm.conf.d/50-unity-greeter.conf
echo "greeter-hide-users=true" >> /usr/share/lightdm/lightdm.conf.d/50-unity-greeter.conf
echo "greeter-show-manual-login=true" >> /usr/share/lightdm/lightdm.conf.d/50-unity-greeter.conf

###################################################################################################################

# PKGS
cp -f data/initial-status.gz /var/log/installer/initial-status.gz
echo "These are the manually installed packages:"
comm -23 <(apt-mark showmanual | sort -u) <(gzip -dc /var/log/installer/initial-status.gz | sed -n 's/^Package: //p' | sort -u)
echo "Take notes"
echo "Adding apt-fast..."

sudo add-apt-repository ppa:apt-fast/stable
sudo apt-get update
sudo apt-get -y install apt-fast

for instpkg in fail2ban ansible aide debsecan debsums lynis auditd audispd-plugins logrotate clamav aide chkrootkit rkhunter libpam-cracklib apparmor gufw psad ufw iptables iptables-persistent nmap; do apt-fast -y install $instpkg; done

for delpkg in xinetd *samba* telnet* transmission* *torrent*; do apt-fast -y purge $delpkg; done

apt-fast -y update
apt-fast -y dist-upgrade

echo 'APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";' > /etc/apt/apt.conf.d/20auto-upgrades

echo 'APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";' > /etc/apt/apt.conf.d/10periodic

find / -iname '*.mp3' -type f -delete
find / -iname '*.mov' -type f -delete
find / -iname '*.mp4' -type f -delete
find / -iname '*.avi' -type f -delete
find / -iname '*.mpg' -type f -delete
find / -iname '*.mpeg' -type f -delete
find / -iname '*.flac' -type f -delete
find / -iname '*.m4a' -type f -delete
find / -iname '*.flv' -type f -delete
find / -iname '*.ogg' -type f -delete
find / -iname '*.gif' -type f -delete
find / -iname '*.png' -type f -delete
find / -iname '*.jpg' -type f -delete
find / -iname '*.jpeg' -type f -delete

###################################################################################################################

cp -f data/login.defs /etc/login.defs

echo 'Configuring PAM!'
cp -Rf /etc/pam.d data/pam.d-img
cp -Rf data/pam.d /etc/pam.d

read -p "Note down PAM points, if any, and then press enter to continue"
cp -Rf data /pam.d-img /etc/pam.d

###################################################################################################################

lamp() {
    echo "Run JShielder!"
    apt-fast -y install apache2 mysql-server php php5-mysql php5 libapache2-mod-php5 php5-mcrypt php5-gd libssh2-php libapache2-modsecurity* libapache2-mod-qos* libapache2-spamhaus*
    cat data/apache-extra >> /etc/apache2/apache2.conf
    echo "apache2: ALL" >> /etc/hosts.allow
    cat data/mysql-extra >> /etc/mysql/my.cnf
    # Honor Cipher Order
    # SSL Disable
}

ssh() {
    cp -f data/sshd_config /etc/ssh/sshd_config
    echo "sshd: ALL" >> /etc/hosts.allow
    find / -iname "*.equiv" -delete
    find / -iname "*.rhosts" -delete 
    find / -iname "*.perms" -delete  
}

vsftpd() {
    cp -f data/vsftpd.conf /etc/vsftpd.conf
    echo "vsftpd: ALL" >> /etc/hosts.allow
    iptables -I INPUT -p tcp --dport 64000:65535 -j ACCEPT
    ufw allow 22/tcp
}

echo
echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
echo -e "\e[93m[+]\e[00m SELECT CRITICAL SERVICE"
echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
echo ""
echo "1. OpenSSH Server"
echo "2. LAMP Stack"
echo "3. vsFTPd Server"
echo "4. Exit"
echo

read menu
case $menu in

1)
ssh
;;

2)
lamp
;;

3)
vsftpd
;;

4)
break
;;

*) ;;

esac