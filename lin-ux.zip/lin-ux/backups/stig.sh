if [ -e /etc/snmp/snmpd.conf ]; then
echo ' Patching GEN005300: SNMPD Password'
    sed -i 's/public/sNMp@$$w0rd4D1$A123/' /etc/snmp/snmpd.conf
    sed -i 's/private/sNMp@$$w0rd4D1$A123/' /etc/snmp/snmpd.conf
    sed -i 's/snmp-trap/sNMp@$$w0rd4D1$A123/' /etc/snmp/snmpd.conf
    sed -i 's/password/sNMp@$$w0rd4D1$A123/' /etc/snmp/snmpd.conf
fi
if [ -e /etc/aide.conf ]; then
    echo ' Remediation: AIDE Configuration for FIPS'
    for GROUP in `awk '/^\//{print $2}' /etc/aide.conf | sort | uniq`; do
        CONFLINE=`awk "/^${GROUP}/{print \\$3}" /etc/aide.conf`
        if [[ "$CONFLINE" != *sha512* ]]; then
            NEWCONFLINE="${CONFLINE}+sha512"
            sed -i -e "s/^${GROUP}.*/${GROUP} = $NEWCONFLINE/g" /etc/aide.conf
        fi

        sed -i -e "s/^\(${GROUP}.*\)md5\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)sha1\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)sha256\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)rmd160\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)tiger\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)haval\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)gost\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)crc32\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e "s/^\(${GROUP}.*\)whirlpool\(.*\)/\1\2/g" /etc/aide.conf | grep DATA
        sed -i -e 's/\+\++/+/g' /etc/aide.conf
    done
fi
if [ -e /etc/aide.conf ]; then
    echo ' Remediation: AIDE Configuration for ACLs '
    for GROUP in `awk '/^\//{print $2}' /etc/aide.conf | sort | uniq`; do
        CONFLINE=`awk "/^${GROUP}/{print \\$3}" /etc/aide.conf`
        if [[ "$CONFLINE" != *acl* ]] && [[ "$CONFLINE" != *R* ]]  && [[ "$CONFLINE" != *L* ]]  && [[ "$CONFLINE" != *\>* ]]; then
            NEWCONFLINE="${CONFLINE}+acl"
            sed -i -e "s/^${GROUP}.*/${GROUP} = $NEWCONFLINE/g" /etc/aide.conf
        fi
    done
fi
if [ -e /etc/aide.conf ]; then
    echo ' Remeiating: AIDE Configuration for xattrs'
    for GROUP in `awk '/^\//{print $2}' /etc/aide.conf | sort | uniq`; do
        CONFLINE=`awk "/^${GROUP}/{print \\$3}" /etc/aide.conf`
        if [[ "$CONFLINE" != *xattrs* ]] && [[ "$CONFLINE" != *R* ]]  && [[ "$CONFLINE" != *L* ]]  && [[ "$CONFLINE" != *\>* ]]; then
            NEWCONFLINE="${CONFLINE}+xattrs"
            sed -i -e "s/^${GROUP}.*/${GROUP} = $NEWCONFLINE/g" /etc/aide.conf
        fi
    done
fi
echo ' Remediating: Forward audit records to the syslog service'
egrep 'active.*no' /etc/audisp/plugins.d/syslog.conf > /dev/null
if [ $? -eq 0 ]; then
        sed -i "s/active = no/active = yes/" /etc/audisp/plugins.d/syslog.conf
        service auditd restart
else
        echo "active = yes" >> /etc/audisp/plugins.d/syslog.conf
        service auditd restart
fi
echo ' CCE-27093-4: Enable NTP Service'
sysv-rc-conf ntpd on
if [ -e /etc/xinetd.d/rexec ]; then
echo ' Patching V-38598: Disable rexec Daemon'
    sed -i 's/[[:blank:]]*disable[[:blank:]]*=[[:blank:]]*no/        disable                 = yes/g' /etc/xinetd.d/rexec
fi
echo ' Patching GEN000020: Configuring Password for'
echo '                     single-user and maintenance'
echo '                     modes.'
`/bin/grep sulogin /etc/inittab | /bin/grep -q wait`
if [ $? -gt 0 ]; then
    echo "" >> /etc/inittab
    echo "~~:S:wait:/sbin/sulogin" >> /etc/inittab
fi
`/bin/grep SINGLE /etc/sysconfig/init | /bin/grep -q sulogin`
if [ $? -gt 0 ]; then
    sed -i "/PROMPT/s/yes/no/" /etc/sysconfig/init
    sed -i "/SINGLE/s/sushell/sulogin/" /etc/sysconfig/init
fi
echo ' Checking GEN000300: Unique Account Names'
echo ' Checking GEN000320: Unique UID'
echo ' Checking GEN000380: Group Verfication'
/usr/sbin/pwck -r
echo ' Patching GEN0000360: System UIDs and GIDs'
echo ' Patching GEN000400: Providing logon-warning banner'
cmp -s ./config/issue /etc/issue
if [ $? -ne 0 ]; then
    cp ./config/issue /etc/issue
fi
exit 0
echo ' Patching GEN000440: Ensure Athentication Logged'
/bin/grep "auth\.\*" /etc/syslog.conf | /bin/grep -q authlog &>/dev/null
if [ $? -gt 0 ]; then
cat >> /etc/syslog.conf << EOF
auth.*          /var/log/authlog
EOF
fi
echo ' GEN000460: Disable after 3 consecutive'
echo '            failed attempts per account'
chmod a-x /usr/sbin/authconfig
chmod a-x /usr/share/authconfig.py
echo ' Patching GEN000480: Set logon delay to 4 seconds.'
`/bin/grep -q FAIL_DELAY /etc/login.defs`
if [ $? -gt 0 ]; then
cat >> /etc/login.defs << EOF
FAIL_DELAY  4
EOF
fi
echo ' Patching GEN000500: Set inactive shell timeout'
cat <<EOF > /etc/profile.d/autologout.sh
TMOUT=900
readonly TMOUT
export TMOUT
EOF
cat <<EOF > /etc/profile.d/autologout.csh
set autologout=15
set -r autologout
EOF
chown root:root /etc/profile.d/autologout.sh
chown root:root /etc/profile.d/autologout.csh
chmod 755 /etc/profile.d/autologout.sh
chmod 755 /etc/profile.d/autologout.csh
echo ' Patching GEN000540: Set minimum number of days'
echo '                     between password changes'
`/bin/grep PASS_MIN_DAYS /etc/login.defs | /bin/grep -q 1`
if [ $? -gt 0 ]; then
    sed -i '/^PASS_MIN_DAYS/ c\PASS_MIN_DAYS\t1' /etc/login.defs
fi
echo ' Patching GEN000580: Set minimum Password length.'
if [ $(/bin/grep PASS_MIN_LEN /etc/login.defs | tail -1 | awk '{ print $2 }') -lt 12 ]; then
    sed -i "s/PASS_MIN_LEN[ \t]*[0-9]*/PASS_MIN_LEN\t15/" /etc/login.defs
fi
echo ' Patching GEN000600: Enforce more secure passwords.'
echo ' Patching GEN000700: Set maximum number of days'
echo '                     between password changes'
`grep PASS_MAX_DAYS /etc/login.defs | grep -q 60`
if [ $? -gt 0 ]; then
    sed -i '/^PASS_MAX_DAYS/ c\PASS_MAX_DAYS\t60' /etc/login.defs
fi
echo ' Patching GEN000800: Disallow duplication passwords.'
echo ' Patching GEN000920: /root is only readable by root'
chmod 700 /root
echo ' Review GEN000940: Root PATH'
echo "\$PATH: $PATH"
echo ' Patching GEN000960: PATH Directory Permissions'
PATHDIRS=`echo $PATH | sed "s/:/ /g"`
for DIR in $PATHDIRS; do
    if [ -d "$DIR" ]; then
            find -H $DIR -maxdepth 1 -type f -perm /0002 -exec chmod o-w {} \;
        fi
done
echo ' Patching GEN000980: Ensure only secure TTY.'
echo "console" > /etc/securetty
echo "tty1" >> /etc/securetty
echo ' Patching GEN001120: Do not allow root remote login'
sed -i "/^PermitRootLogin/ c\PermitRootLogin no" /etc/ssh/sshd_config
echo ' Patching GEN001140: System File Permissions'
for CHKDIR in /etc /bin /usr/bin /usr/lbin /usr/usb /sbin /usr/sbin /usr/local/bin /usr/local/sbin
do
  if [ -d "$CHKDIR" ]; then
    for FILENAME in `find $CHKDIR`; do
      if [ -e "$FILENAME" ]; then
        FILEPERMS=`stat -L --format='%04a' $FILENAME`
        FILESPECIAL=${FILEPERMS:0:1}
        FILEOWNER=${FILEPERMS:1:1}
        FILEGROUP=${FILEPERMS:2:1}
        FILEOTHER=${FILEPERMS:3:1}
        if [ $(($FILEOWNER&4)) -eq 0 -a $((FILEGROUP&4)) -ne 0 ]; then
          chmod g-r $FILENAME
        fi
        if [ $(($FILEOWNER&4)) -eq 0 -a $((FILEOTHER&4)) -ne 0 ]; then
          chmod o-r $FILENAME
        fi
        if [ $(($FILEOWNER&2)) -eq 0 -a $((FILEGROUP&2)) -ne 0 ]; then
          chmod g-w $FILENAME
        fi
        if [ $(($FILEOWNER&2)) -eq 0 -a $((FILEOTHER&2)) -ne 0 ]; then
          chmod o-w $FILENAME
        fi
        if [ $(($FILEOWNER&1)) -eq 0 -a $((FILEGROUP&1)) -ne 0 ]; then
          chmod g-x $FILENAME
        fi
        if [ $(($FILEOWNER&1)) -eq 0 -a $((FILEOTHER&1)) -ne 0 ]; then
          chmod o-x $FILENAME
        fi
      fi
    done
  fi
done
echo ' Patching GEN001180: Network Service Permissions'
for FILE in `find /usr/sbin/ -type f -perm +022`; do
  if [ -e "$FILE" ]; then
    PERMS=`stat -L --format='%04a' $FILE`
     FILESPECIAL=${PERMS:0:1}
     FILEOWNER=${PERMS:1:1}
     FILEGROUP=${PERMS:2:1}
     FILEOTHER=${PERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&0)) != "0" ] || [ $(($FILEGROUP&2)) != "0" ] || [ $(($FILEOTHER&2)) != "0" ]; then
        chmod u-s,g-ws,o-wt $FILE
    fi
  fi
done
echo ' Patching GEN001190: Remove ACLs /usr/sbin'
for FILE in `find /usr/sbin/ ! -type l`; do
    if [ -e "$FILE" ]; then
            ACL=`getfacl --skip-base $FILE 2>/dev/null`;
            if [ "$ACL" != "" ]; then
                setfacl --remove-all $FILE
        fi
    fi
done
echo ' Patching GEN001200: System Command Permissions'
for CHKDIR in '/etc /bin /usr/bin /usr/lbin /usr/usb /sbin /usr/sbin /usr/local/bin /usr/local/sbin'; do
  if [ -d "$CHKDIR" ]; then
    for FILENAME in `find $CHKDIR ! -type l`; do
      if [ -e "$FILENAME" ]; then
        FILEPERMS=`stat -L --format='%04a' $FILENAME`
        FILESPECIAL=${FILEPERMS:0:1}
        FILEOWNER=${FILEPERMS:1:1}
        FILEGROUP=${FILEPERMS:2:1}
        FILEOTHER=${FILEPERMS:3:1}
        if [ $(($FILEOWNER&0)) != "0" ] || [ $(($FILEGROUP&2)) != "0" ] || [ $(($FILEOTHER&2)) != "0" ]; then
          chmod g-w,o-w $FILENAME
        fi
      fi
    done
  fi
done
echo ' Patching GEN001220: System Command Ownership'
function is_system_user {
   CURUSER=$1
   for SYSUSER in `awk -F ':' '{if($3 < 500) print $1}' /etc/passwd`; do
     if [ "$SYSUSER" = "$CURUSER" ]; then
       return 0
     fi
   done
   return 1
}
for CHKDIR in '/etc /bin /usr/bin /usr/lbin /usr/usb /sbin /usr/sbin /usr/local/bin /usr/local/sbin'; do
  if [ -d "$CHKDIR" ]; then
    for FILENAME in `find $CHKDIR ! -type l`; do
      if [ -e "$FILENAME" ]; then
        CUROWN=`stat -c %U $FILENAME`;
        is_system_user $CUROWN
        if [ $? -ne 0 ]; then
          chown root $FILENAME
        fi
      fi
    done
  fi
done
echo ' Patching GEN001240: System Group Ownership'
function is_system_group {
    CURGROUP=$1
    for SYSGROUP in `awk -F ':' '{if($3 < 500) print $1}' /etc/group`; do
        if [ "$SYSGROUP" = "$CURGROUP" ]; then
            return 0
        fi
    done
    return 1
}
for CHKDIR in '/etc /bin /usr/bin /usr/lbin /usr/usb /sbin /usr/sbin /usr/local/bin /usr/local/sbin'; do
    if [ -d "$CHKDIR" ];  then
        for FILENAME in `find $CHKDIR ! -type l`; do
            if [ -e "$FILENAME" ]; then
                CURGROUP=`stat -c %G $FILENAME`;
                is_system_group $CURGROUP
                if [ $? -ne 0 ]; then
                    chgrp root $FILENAME
                fi
                fi
        done
    fi
done
echo ' Patching GEN001260: Setting permissions of system'
echo '                     log files, part 2.'
sed -i "s/chmod 0664/chmod 0600/" /etc/rc.d/rc.sysinit
echo ' Patching GEN001260: Setting permissions of system'
echo '                     log files.'
find /var/log/ -type f -exec chmod 600 '{}' \;

echo ' Patching GEN001270: Remove ACLs from Log Files'
LOGFILES=`find /var/log/ -type f -print | grep -v wtmp`
for LOGFILETOFIX in $LOGFILES; do
    ACLOUT=`getfacl --skip-base $LOGFILETOFIX 2>/dev/null`;
        if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all $LOGFILETOFIX
        fi
done

echo ' Patching GEN001300: Library Permissions'
for LIBDIR in /usr/lib /usr/lib64 /lib /lib64
do
  if [ -d $LIBDIR ]; then
        for BADLIBFILE in `find $LIBDIR -type f -perm /7022 \( -name *.so* -o -name *.a* \)`; do
          chmod o-s,g-ws,o-wt $BADLIBFILE
        done
  fi
done

echo ' Patching GEN001360: NIS File Permissions'
if [ -d /var/yp ]; then
    BADYPFILE=`find /var/yp/ -type f -perm /7022`
    for BADFILE in $BADYPFILE; do
        chmod u-s,g-ws,o-wt $BADFILE
    done
fi

if [ -d /var/yp ]; then
    echo ' Patching GEN001361: Remove ACLs from NIS'
    for FILE in `find /var/yp -type f`; do
        ACLOUT=`getfacl --skip-base $FILE 2>/dev/null`;
        if [ "$ACLOUT" != "" ]; then
                setfacl --remove-all $FILE
        fi
    done
fi

if [ -a "/etc/resolv.conf" ]; then
echo ' Patching GEN001363: /etc/resolv.conf Group'
echo '                     Ownership'
    CURGOWN=`stat -c %G /etc/resolv.conf`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "system" ]; then
        chgrp root /etc/resolv.conf
    fi
fi

if [ -a "/etc/resolv.conf" ]; then
    echo ' Patching GEN001365: Remove ACLs from resolv.conf'
    ACLOUT=`getfacl --skip-base /etc/resolv.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/resolv.conf
        fi
fi

if [ -a "/etc/hosts" ]; then
    echo ' Patching GEN001366: /etc/hosts Ownership'
    CUROWN=`stat -c %U /etc/hosts`;
    if [ "$CUROWN" != "root" ]; then
        chown root /etc/hosts
    fi
fi

if [ -a "/etc/hosts" ]; then
    echo ' Patching GEN001368: /etc/hosts Permissions'
    FILEPERMS=`stat -L --format='%04a' /etc/hosts`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&3)) != "0" ] || [ $(($FILEOTHER&3)) != "0" ]; then
        chmod u-xs,g-wxs,o-wxt /etc/hosts
    fi
fi

if [ -a "/etc/hosts" ]; then
    echo ' Patching GEN001369: Remove ACLs from /etc/hosts'
    ACLOUT=`getfacl --skip-base /etc/hosts 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/hosts
    fi
fi

if [ -a "/etc/nsswitch.conf" ]; then
    echo ' Patching GEN001371: /etc/nsswitch.conf Ownership'
    CUROWN=`stat -c %U /etc/nsswitch.conf`;
    if [ "$CUROWN" != "root" ]; then
        chown root /etc/nsswitch.conf
    fi
fi

if [ -a "/etc/nsswitch.conf" ]; then
    echo ' Patching GEN001372: /etc/nsswitch.conf Group'
    echo '                     Ownership'
    CURGOWN=`stat -c %G /etc/nsswitch.conf`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "system" ]; then
        chgrp root /etc/nsswitch.conf
    fi
fi

if [ -a "/etc/nsswitch.conf" ]; then
    echo ' Patching GEN001373: /etc/nsswitch.conf Permissions'
    FILEPERMS=`stat -L --format='%04a' /etc/nsswitch.conf`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&3)) != "0" ] || [ $(($FILEOTHER&3)) != "0" ]; then
        chmod u-xs,g-wxs,o-wxt /etc/nsswitch.conf
    fi
fi
if [ -a "/etc/nsswitch.conf" ]; then
    echo ' Patching GEN001374: Remove ACLS from'
    echo '                     /etc/nsswitch.conf'
    ACLOUT=`getfacl --skip-base /etc/nsswitch.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/nsswitch.conf
    fi
fi
if [ -a "/etc/passwd" ]; then
    echo ' Patching GEN001378: /etc/passwd Ownership'
    CUROWN=`stat -c %U /etc/passwd`;
    if [ "$CUROWN" != "root" ]; then
            chown root /etc/passwd
    fi
fi
if [ -a "/etc/passwd" ]; then
    echo ' Patching GEN001379: /etc/passwd Group Ownership'
    CURGOWN=`stat -c %G /etc/passwd`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "system" ]; then
        chgrp root /etc/passwd
    fi
fi
if [ -a "/etc/passwd" ]; then
    echo ' Patching GEN001390: Remove ACLS from /etc/passwd'
    ACLOUT=`getfacl --skip-base /etc/passwd 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/passwd
    fi
fi
if [ -a "/etc/group" ]; then
    echo ' Patching GEN001391: /etc/group Ownership'
    CUROWN=`stat -c %U /etc/group`;
    if [ "$CUROWN" != "root" ]; then
        chown root /etc/group
    fi
fi
if [ -a "/etc/group" ]; then
    echo ' Patching GEN001392: /etc/group Group Ownership'
    CURGOWN=`stat -c %G /etc/group`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "system" ]; then
        chgrp root /etc/group
    fi
fi
if [ -a "/etc/group" ]; then
    echo ' Patching GEN001393: /etc/group Permissions'
    FILEPERMS=`stat -L --format='%04a' /etc/group`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
        FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&3)) != "0" ] || [ $(($FILEOTHER&3)) != "0" ]; then
        chmod u-xs,g-wxs,o-wxt /etc/group
        fi
fi
if [ -a "/etc/group" ]; then
    echo ' Patching GEN001394: Remove ACLS from /etc/group'
    ACLOUT=`getfacl --skip-base /etc/group 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/group
    fi
fi
if [ -a "/etc/shadow" ]; then
    echo ' Patching GEN001410: /etc/shadow Group Ownership'
    CURGOWN=`stat -c %G /etc/shadow`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "system" ]; then
        chgrp root /etc/shadow
    fi
fi
if [ -a "/etc/shadow" ]; then
    echo ' Patching GEN001430: Remove ACLS from /etc/shadow'
    ACLOUT=`getfacl --skip-base /etc/shadow 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/shadow
    fi
fi
BADHASH=`awk -F ':' '{if($2 != "x" && $2 != "*") print $1}' /etc/passwd | tr "\n" " "`
if [ "$BADHASH" != "" ]; then
    echo ' Checking GEN001470: Password Hashes in /etc/passwd'
    echo "------------------------------"
    echo
    echo "${BADHASH}"
    echo
    echo "------------------------------"
fi
BADHASH=`awk -F ':' '{if($2 != "x" && $2 != "*") print $1}' /etc/group | tr "\n" " "`
if [ "$BADHASH" != "" ]; then
    echo ' Checking GEN001475: Password Hashes in /etc/group'
    echo "------------------------------"
    echo
    echo "${BADHASH}"
    echo
    echo "------------------------------"
fi
echo ' Patching GEN001480: Home Directory Permissions'
Answer=0
Char1=""
UserName=""
UserDir=""
for UserName in ${USERACCT}; do
    UserDir=`grep "^${UserName}:" /etc/passwd | cut -d':' -f6`
    if [ "${UserDir}X" != "X" -a "${UserDir}" != '/' ]; then
        if [ -d "${UserDir}" ]; then
            PERM=`ls -lLd ${UserDir} |cut -c6,8,9,10`
            if [ ${PERM} != "----" ]; then
            chmod 750 ${UserDir}
            fi
done
echo ' Patching GEN001500: Home Directory Ownership'
for UserName in `awk -F':' '!/nfsnobody/{if($3 >= 500) print $1}' /etc/passwd`; do
    if [ `echo $UserName | cut -c1` != '+' ]; then
        PwTest=`grep "^${UserName}:" /etc/passwd | cut -d: -f6`
        PwHomeDir=${PwTest:-NOVALUE}
        if [ "${PwHomeDir}" != "NOVALUE" -a "${PwHomeDir}" != " " ]; then
            if [ -d ${PwHomeDir} ]; then
                if [ ${PwHomeDir} = '/' ]; then
                    echo 'WARNING:  Home directory for "'${UserName}'"' \
                    '("'${PwHomeDir}'") excluded from check.'
                else
            CUROWN=`stat -c %U ${PwHomeDir}`;
            if [ "$CUROWN" != "$UserName" ]; then
                chown $UserName ${PwHomeDir}
            fi
                fi
            fi
        fi
    fi
done
echo ' Patching GEN001520: Home Directory Group Ownership'
for UserName in `awk -F':' '!/nfsnobody/{if($3 >= 500) print $1}' /etc/passwd`; do
    if [ `echo $UserName | cut -c1` != '+' ]; then
        PwTest=`grep "^${UserName}:" /etc/passwd | cut -d: -f6`
        PwHomeDir=${PwTest:-NOVALUE}
        if [ "${PwHomeDir}" != "NOVALUE" -a "${PwHomeDir}" != " " ]; then
            if [ -d ${PwHomeDir} ]; then
                if [ ${PwHomeDir} = '/' ]; then
                    echo 'WARNING:  Home directory for "'${UserName}'"' \
                    '("'${PwHomeDir}'") excluded from check.'
                else
                PWGID=`grep "^${UserName}:" /etc/passwd | cut -d: -f4`
                CURGID=`stat -c %g ${PwHomeDir}`;
            if [ "$CURGID" != "$PWGID" ]; then
                chgrp $PWGID ${PwHomeDir}
            fi
                fi
            fi
        fi
    fi
done
echo ' Patching GEN001550: Home Directory File Ownership'
DotFiles='( -name .cshrc
                -o -name  .login
                -o -name  .logout
                -o -name  .profile
                -o -name  .bash_profile
                -o -name  .bbashrc
                -o -name  .env
                -o -name  .dtprofile
                -o -name  .dispatch
                -o -name  .emacs
                -o -name  .exrc )'
for UserName in `awk -F':' '!/nfsnobody/{if($3 >= 500) print $1}' /etc/passwd`; do
    if [ `echo $UserName | cut -c1` != '+' ]; then
        PwTest=`grep "^${UserName}:" /etc/passwd | cut -d: -f6`
        PwHomeDir=${PwTest:-NOVALUE}
        if [ "${PwHomeDir}" != "NOVALUE" -a "${PwHomeDir}" != " " ]; then
            if [ -d ${PwHomeDir} ]; then
                if [ ${PwHomeDir} = '/' ]; then
                    echo 'WARNING:  Home directory for "'${UserName}'"' \
                    '("'${PwHomeDir}'") excluded from check.'
                else
                    PWGID=`grep "^${UserName}:" /etc/passwd | cut -d: -f4`
            GIDLINE="! ( -gid ${PWGID}"
            for CGID in `id -G ${UserName}`; do

            if [ "$CGID" != "$PWGID" ]; then
                    GIDLINE="${GIDLINE} -o -gid ${CGID}"
            fi
            done
            GIDLINE="$GIDLINE )"
            find ${PwHomeDir} -xdev ${GIDLINE} ! -fstype nfs  ! ${DotFiles} -exec chgrp ${PWGID} {} \; 2>/dev/null
                fi
            fi
        fi
    fi
done
echo ' Patching GEN001560: Set home dir permissions'
for BASEDIR  in "/home/* /root"
do
    find $BASEDIR -type f -exec chmod 600 '{}' \;
    find $BASEDIR -type d -exec chmod 700 '{}' \;
done
echo ' Checking GEN001570: Remove ACLs in Home Directories'
HOMEDIRS=$(cut -d: -f6 /etc/passwd|sort|uniq|grep -v "^/$")
for DIR in $HOMEDIRS; do
    if [ -e $DIR ]; then
        setfacl -R --remove-all $DIR
    fi
done
echo ' Patching GEN001500: Remove ACLs for Init Scripts'
BADFACL=$( getfacl -R --skip-base --absolute-names /etc/rc.* /etc/init.d | grep file| awk '{print $3}')
for BADFILE in $BADFACL; do
    if [ -e $BADFILE ]; then
        setfacl --remove-all $BADFILE
    fi
done
echo ' Patching GEN001620: Remove suid and sgid bit from'
echo '                     run control scripts.'
chmod ug-s /etc/rc.d/init.d/*
echo ' Patching GEN001660: Set owner of run control'
echo '                     scripts'
chown root /etc/rc.d/init.d/*
echo ' Patching GEN001680: Set group owner of run control'
echo '                     scripts'
chgrp root /etc/rc.d/init.d/*
echo ' Patching GEN001730: Remove ACLs from Init Files'
GLOBALINIT=$( ls -l /etc/profile /etc/bashrc /etc/csh.login /etc/csh.cshrc /etc/environment /etc/.login /etc/security/environ /etc/profile.d/* 2>/dev/null|grep "\+ "|awk '{print $9}' )
for line in $GLOBALINIT; do
    setfacl --remove-all $line
done
echo ' Patching GEN001740: Set owner of global'
echo '                     initialization files'
chown root /etc/{profile,bashrc,environment}
echo ' Patching GEN001760: Set group owner of global'
echo '                     initialization files'
chgrp root /etc/{profile,bashrc,environment}
echo ' Patching GEN001810: Remove ACLs for /etc/skel'
BADSKELACL=$( getfacl -R --skip-base --absolute-names /etc/skel | grep file| awk '{print $3}' )
for FILE in $BADSKELACL; do
    if [ -e $FILE ]; then
        setfacl --remove-all $FILE
    fi
done
echo ' Patching GEN001820: Set owner of default/skel files'
find /etc/skel -type f -exec chown root '{}' \;
echo ' Patching GEN001830: /etc/skel Ownership'
BADSKELGRP=$( find /etc/skel/ ! -group root ! -group bin )
for FILE in $BADSKELGRP; do
    if [ -e $FILE ]; then
        chgrp root $FILE
    fi
done
echo ' Patching GEN001860: Local Init File Ownership'
ALREADY=0
Answer=4
DotFiles='( -name .cshrc
        -o -name  .login
        -o -name  .logout
        -o -name  .bash_logout
        -o -name  .bash_login
        -o -name  .profile
        -o -name  .bash_profile
        -o -name  .bashrc
        -o -name  .env
        -o -name  .dtprofile
        -o -name  .dispatch
        -o -name  .emacs
        -o -name  .exrc )'
for UserName in ${USERACCT}; do
    if [ `echo $UserName | cut -c1` != '+' ]; then
        PwTest=`grep "^${UserName}:" /etc/passwd | cut -d: -f6`
        PwHomeDir=${PwTest:-NOVALUE}
        if [ "${PwHomeDir}" != "NOVALUE" -a "${PwHomeDir}" != " " ]; then
            if [ -d ${PwHomeDir} ]; then
                if [ ${PwHomeDir} = '/' ]; then
                    echo 'WARNING:  Home directory for "'${UserName}'"' \
                    '("'${PwHomeDir}'") excluded from check.'
                else

                    for filename in `find ${PwHomeDir}                   \
            -xdev                           \
                        -type f                         \
                        ! -fstype nfs                   \
                         ${DotFiles}                   \
                        ! -user ${UserName}             \
                        -exec ls -adlL {} \;            \
                        | tr -s " " | awk '{print $9}'`
                    do
                        GroupName=`id $UserName|cut -d "(" -f 4|tr ")" " "`
                        chown $UserName $filename
                    done
                fi
            fi
        fi
    fi
done
echo ' Patching GEN001870: Initilization File Ownership'
ALREADY=0
Answer=4
DotFiles='( -name .cshrc
        -o -name  .login
        -o -name  .logout
        -o -name  .bash_logout
        -o -name  .bash_login
        -o -name  .profile
        -o -name  .bash_profile
        -o -name  .bashrc
        -o -name  .env
        -o -name  .dtprofile
        -o -name  .dispatch
        -o -name  .emacs
        -o -name  .exrc )'
for UserName in ${USERACCT}; do
    if [ `echo $UserName | cut -c1` != '+' ]; then
        PwTest=`grep "^${UserName}:" /etc/passwd | cut -d: -f6`
        PwHomeDir=${PwTest:-NOVALUE}
        if [ "${PwHomeDir}" != "NOVALUE" -a "${PwHomeDir}" != " " ]; then
            if [ -d ${PwHomeDir} ]; then
                if [ ${PwHomeDir} = '/' ]; then
                    echo 'WARNING:  Home directory for "'${UserName}'"' \
                    '("'${PwHomeDir}'") excluded from check.'
                else
            PGID=`egrep "^${UserName}" /etc/passwd | awk -F':' '{print $4}'`
            for filename in `find ${PwHomeDir}     \
                -xdev                              \
                        -type f                            \
                        ! -fstype nfs                      \
                         ${DotFiles}                       \
                        ! -gid ${PGID}                     \
                        ! -gid 0                           \
                        -exec ls -adlL {} \;               \
                        | tr -s " " | awk '{print $9}'`; do
                chgrp $PGID $filename
            done
                fi
            fi
        fi
    fi
done
echo ' Patching GEN001880: Initialization File Permissions'
find $(awk -F: '{ print $6 }' /etc/passwd|sort|uniq|grep -v '^/$') -maxdepth 1 -type f \( -name .login -o -name .cshrc -o -name .logout -o -name .profile -o -name .bashrc -o -name .bash_logout -o -name .bash_profile -o -name .bash_login -o -name .env -o -name .dispatch -o -name .emacs -o -name .exrc \) -perm /7037 -exec chmod u-s,g-wxs,o-rwxt {} \;
find $(awk -F: '{ print $6 }' /etc/passwd|sort|uniq|grep -v '^/$') -maxdepth 1 \( -name .dt -o -name .dtprofile \) -perm /7022 -exec chmod u-s,g-ws,o-wt {} \;
echo ' Patching GEN001890: Remove ACLs from Initilization'
echo '                     Files'
HOMEDIR=$( cut -d : -f 6 /etc/passwd | grep -v "^/$" )
for FILE in $BADFACL; do
    if [ -e $FILE ]; then
        setfacl --remove-all $FILE
    fi
done
echo ' Patching GEN001940: Fix Init File Permissions'
FILES=".login .cshrc .logout .profile .bash_profile .bashrc .bash_logout .env .dtprofile .dispatch .emacs .exrc"
DISAJUNK=$( for HOMEDIR in `cut -d: -f6 /etc/passwd | sort | uniq | grep -v "^/$"`; do
  for INIFILE in $FILES; do
    REFLIST=$( egrep " [\"~]?/" ${HOMEDIR}/${INIFILE} 2>/dev/null|sed "s/.*\([~ \"]\/[\.0-9A-Za-z_\/\-]*\).*/\1/")
        for REFFILE in $REFLIST; do
        FULLREF=$( echo $REFFILE | sed "s:\~:${HOMEDIR}:g" | sed "s:^\s*::g" )
            dirname $FULLREF|xargs stat -c "dir:%a:%n" | cut -d ":" -f 3
            stat -c "file:%:%n" $FULLREF | cut -d ":" -f 3
        done | sort | uniq
  done
done)
BADFILE=$( for file in $DISAJUNK; do
           find $file -maxdepth 0 -perm -002 -type d  | grep $file
       done | sort | uniq )
for line in $BADFILE; do
    chmod o-w $line
done
echo ' Patching GEN001980: Plus (+) in Access Control'
echo '                     Files'
for ACF in `find / -name .rhosts -o -name .shosts -o -name hosts.equiv -o -name shosts.equiv` /etc/passwd /etc/shadow /etc/group; do
    grep '^+' $ACF > /dev/null
    if [ $? -eq 0 ]; then
        sed -i -e '/^\+/d' $ACF
    fi
done
echo ' Patching GEN002000: Remove .netrc Files'
NETRCFILE=$( find / -name .netrc )
for FILE in $NETRCFILE; do
    rm -f $FILE
done
echo ' Patching GEN02020: Remove Remote Access Control'
find / \( -name '.rhosts' -o -name '.shosts' -o -name 'hosts.equiv' -o -name 'shosts.equiv' \) -exec rm -f {} \;
echo ' Patching GEN002060: Access Control Permissions'
GEN002060FILES=$( find / -name .rhosts -o -name  .shosts -o -name  hosts.equiv -o -name shosts.equiv )
for line in $GEN002060FILES; do
  chmod 700 $line
done
echo '===================================================='
echo ' Patching GEN002100: Remove pam_rhosts_auth from PAM'
echo '===================================================='
`grep -q pam_rhosts_auth /etc/pam.d/*`
if [ $? -gt 0 ]; then
    for NAME in `grep -l pam_rhosts_auth /etc/pam.d/*`; do
        sed -i '/pam_rhosts_auth/d' $NAME
    done
fi
echo ' Patching GEN002120: Set /etc/shells'
cat <<EOF > /etc/shells
/bin/sh
/bin/bash
/sbin/nologin
/bin/tcsh
/bin/csh
EOF
echo ' Patching GEN002140: Default Shells'
for CURSHELL in `awk -F':' '{print $7}' /etc/passwd | sort | uniq`;do
  if [ "$CURSHELL" != "/usr/bin/false" -a "$CURSHELL" != "/bin/false" -a "$CURSHELL" != "/bin/null" -a "$CURSHELL" != "/sbin/nologin" -a "$CURSHELL" != "/bin/sync" -a "$CURSHELL" != "/bin/halt" -a "$CURSHELL" != "/bin/shutdown" -a "$CURSHELL" != "/bin/sdshell" ]; then
    grep "$CURSHELL" /etc/shells > /dev/null
    if [ $? -ne 0 ]; then
    echo $CURSHELL >> /etc/shells
    fi
  fi
done
for BADSHELL in /usr/bin/false /bin/false /dev/null /sbin/nologin /bin/sync /sbin/halt /sbin/shutdown sdshell; do
  grep "$BADSHELL" /etc/shells > /dev/null
  if [ $? -eq 0 ]; then
    sed -i -e "\:${BADSHELL}:d" /etc/shells
  fi
done
echo ' Patching GEN002180: No shells have sgid bit set'
for SHELL in `cat /etc/shells`; do
    chmod g-s $SHELL
done
echo ' Patching GEN002210: All Shell Files must be owned'
echo '                     by root'
find /bin/bash /sbin/nologin /bin/tcsh /bin/csh /bin/ksh /bin/sync /sbin/shutdown /sbin/halt ! -group root ! -group bin ! -group sys -exec chgrp root {} \; 2> /dev/null
echo ' Patching GEN002220: Set shell permissions'
for SHELL in `cat /etc/shells`; do
    chmod 755 $SHELL
done
echo ' Patching GEN002230: Remove ACLs from Shell Files'
SHELLS=$(cat /etc/shells)
for FILE in $SHELLS; do
    if [ -x $FILE ]; then
        setfacl --remove-all $FILE
    fi
done
echo ' Patching GEN002280: Device Permissions'
WWWFiles=$( find / -perm -2 -a \( -type b -o -type c \) 2>/dev/null | egrep -v '(/dev/full|/dev/random|/dev/zero|/dev/tty|/dev/ptmx|/dev/null|/dev/urandom)' )
for file in $WWWFiles; do
    chmod o-w $file
done
echo ' Patching GEN002300: Device Files Ownership'
if [ ! -e "/etc/udev/rules.d/10-GEN002300.rules" ]; then
cat << EOF > /etc/udev/rules.d/10-GEN002300.rules
SUBSYSTEM=="ide", SYSFS{media}=="tape", ACTION=="add", \
                RUN+="modprobe $env{UDEV_MODPROBE_DBG} ide-scsi idescsi_nocd=1"
KERNEL=="ht*",                  OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="nht*",                 OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="pt[0-9]*",             OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="npt*",                 OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="st*",                  OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="nst*",                 OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="osst*",                OWNER=root, GROUP="disk", MODE="0640"
KERNEL=="nosst*",               OWNER=root, GROUP="disk", MODE="0640"
EOF
  chown root:root /etc/udev/rules.d/10-GEN002300.rules
  chmod 644 /etc/udev/rules.d/10-GEN002300.rules
  chcon "system_u:object_r:udev_var_run_t:s0" /etc/udev/rules.d/10-GEN002300.rules
fi
echo ' Patching GEN002320: Setting permissions on audio'
echo '                     devices.'
if [ -e /etc/security/console.perms.d/50-default.perms ]; then
    sed -i -r "/sound|snd|mixer/ d" /etc/security/console.perms.d/50-default.perms
fi
echo "SUBSYSTEM==\"sound|snd\", OWNER=\"root\", GROUP=\"root\", MODE=\"0644\"" > /etc/udev/rules.d/55-audio-perms.rules
echo ' Patching GEN002230: Remove ACLs from Audio Devices'
echo ' Patching GEN002340: Set owner of audio device'
echo ' Patching GEN002360: Set group of audio device'
echo ' Patching GEN002420: Mount filesystems with nosuid'
echo ' Patching GEN002430: Mount filesystems with nodev'
FSTAB=/etc/fstab
SED=`which sed`
    if [ $(grep " \/sys " ${FSTAB} | grep -c "nosuid") -eq 0 ]; then
            MNT_OPTS=$(grep " \/sys " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/sys.*${MNT_OPTS}\)/\1,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/boot " ${FSTAB} | grep -c "nosuid") -eq 0 ]; then
            MNT_OPTS=$(grep " \/boot " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/boot.*${MNT_OPTS}\)/\1,nodev,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/usr " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/usr " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/usr .*${MNT_OPTS}\)/\1,nodev,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/home " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/home " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/home .*${MNT_OPTS}\)/\1,nodev,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/export\/home " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/export\/home " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/export\/home .*${MNT_OPTS}\)/\1,nodev,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/usr\/local " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/usr\/local " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/usr\/local.*${MNT_OPTS}\)/\1,nodev,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/dev\/shm " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/dev\/shm " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/dev\/shm.*${MNT_OPTS}\)/\1,nodev,noexec,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/tmp " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/tmp " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/tmp.*${MNT_OPTS}\)/\1,nodev,noexec,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/var\/tmp " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/var\/tmp " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/var\/tmp.*${MNT_OPTS}\)/\1,nodev,noexec,nosuid/" ${FSTAB}
    fi

    if [ $(grep " \/var\/log " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/var\/tmp " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/var\/tmp.*${MNT_OPTS}\)/\1,nodev,noexec,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/var\/log\/audit " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/var\/log\/audit " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/var\/log\/audit.*${MNT_OPTS}\)/\1,nodev,noexec,nosuid/" ${FSTAB}
    fi
    if [ $(grep " \/var " ${FSTAB} | grep -c "nodev") -eq 0 ]; then
            MNT_OPTS=$(grep " \/var " ${FSTAB} | awk '{print $4}')
            ${SED} -i "s/\( \/var.*${MNT_OPTS}\)/\1,nodev,nosuid/" ${FSTAB}
    fi
echo ' Patching GEN002480: World Writable Files and'
echo '                     Directories'
WWWFILES=$( find / -perm -2 -a \( -type d -o -type f \) 2> /dev/null |egrep -v "^/proc|^/tmp|^/dev|^/var/spool/vbox|^/var/tmp|^/var/cache/coolkey|^/selinux" )
for line in $WWWFILES; do
    chmod o-w $line
done
echo ' Patching GEN002500: Public Directory Ownership'
find / -type d -perm -1002 ! -user root -exec chown root {} \; 2>/dev/null
echo ' Patching GEN002560: Set default umask.'
`grep umask /etc/bashrc | grep -q 077`
if [ $? -gt 0 ]; then
    sed -i "/umask/ c\umask 077" /etc/bashrc
fi
`grep umask /etc/csh.cshrc | grep -q 077`
if [ $? -gt 0 ]; then
    sed -i "/umask/ c\umask 077" /etc/csh.cshrc
fi
`grep umask /etc/profile | grep -q 077`
if [ $? -gt 0 ]; then
    sed -i "/umask/ c\umask 077" /etc/profile
fi
`grep umask /etc/init.d/functions | grep -q 027`
if [ $? -gt 0 ]; then
    sed -i "/umask/ c\umask 027" /etc/init.d/functions
fi
echo ' Patching GEN002640: Lock default system accounts'
for NAME in `cut -d: -f1 /etc/passwd`; do
    NAMEID=`id -u $NAME`
    if [ $NAMEID -lt 500 -a $NAME != 'root' -a $NAME != 'oracle' -a $NAME != 'postgres' ]; then
            /usr/sbin/usermod -L -s /sbin/nologin $NAME
        fi
done
echo ' Patching GEN002660: Turn on auditing'
/sbin/sysv-rc-conf --levels 0123456 auditd on
echo ' Patching GEN002680: Set audit directory permissions'
chmod 700 /var/log/audit
LOGFILES=$( grep "^log_file" /etc/audit/auditd.conf|sed s/^[^\/]*//|xargs stat -c %U:%n | cut -d ":" -f 2 )
BADELOGFILES=$( for line in $LOGFILES; do find $line ! -group root ! -group sys ! -group bin ; done )
echo ' Patching GEN005590: Audit Log File Ownership'
for file in $BADELOGFILES; do
    chgrp root $file
done
echo ' Patching GEN002710: Remove ACLs from Log Files'
LOGACLFILES=$( grep "^log_file" /etc/audit/auditd.conf|sed s/^[^\/]*//|xargs ls -l | awk '{print $9}' )
for FILE in $BADLOGACLFILES; do
    setfacl --remove-all $FILE
done
echo ' Patching GEN002720: Aduit logon/logout'
echo ' Patching GEN002740: Audit DAC permission changes'
echo ' Patching GEN002760: Audit unauthorized file access'
echo ' Patching GEN002780: Audit use of privileged command'
echo ' Patching GEN002800: Audit deletions'
echo ' Patching GEN002820: Audit sys admin actions'
echo ' Patching GEN002840: Audit security personnel action'
echo ' Patching GEN002860: Rotate audit logs daily'
cat <<EOF > /etc/logrotate.d/audit
/var/log/audit/audit.log {
    daily
    notifempty
    missingok
    postrotate
    /sbin/service auditd restart 2> /dev/null > /dev/null || true
    endscript
}
EOF
echo ' Patching GEN002960: Cron Utility Accessibility'
if [ ! -f /etc/cron.allow ]; then
    touch /etc/cron.allow
fi
if [ ! -f /etc/cron.deny ];then
    touch /etc/cron.deny
fi
echo ' Patching GEN002990: Remove ACLs from /etc/cron.allow'
ACLOUT=`getfacl --skip-base /etc/cron.allow 2>/dev/null`;
if [ "$ACLOUT" != "" ]; then
    setfacl --remove-all /etc/cron.allow
fi
echo ' Patching GEN003050: Cron File Group Ownership'
find /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/cron.d /etc/crontab /etc/cron.allow ! -group root -type f -exec chgrp root {} \; > /dev/null
for USERCRON in `find /var/spool/cron -type f`; do
  USERNAME=`basename $USERCRON`
  GROUPNAME=`id -g -n $USERNAME`
  find $USERCRON -type f ! -group $GROUPNAME ! -group root -exec chgrp $GROUPNAME {} \;
done
echo ' Patching GEN003060: Limit default account cron'
echo '                     abilities'
echo 'root' > /etc/cron.allow
awk -F: '{print $1}' /etc/passwd | grep -v root > /etc/cron.deny
echo ' Patching GEN003080: Cron File Permissions'
chmod -R 700 /etc/cron.daily
chmod -R 700 /etc/cron.hourly
chmod -R 700 /etc/cron.weekly
chmod -R 700 /etc/cron.monthly
chmod 600 /etc/crontab
chmod 600 /etc/anacrontab
chmod -R 600 /etc/cron.d
chmod -R 600 /var/spool/cron
echo ' Patching GEN003090: Remove ACLs from Cron Files'
for CRONFILE in `find /var/spool/cron /etc/cron.d /etc/crontab /etc/cron.daily /etc/cron.hourly /etc/cron.monthly /etc/cron.weekly -type f 2>/dev/null`; do
    ACLOUT=`getfacl --skip-base $CRONFILE 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all $CRONFILE
    fi
done
echo ' Patching GEN003100: Set crontab directory'
echo '                     permissions'
chmod 700 /etc/cron.hourly
chmod 700 /etc/cron.daily
chmod 700 /etc/cron.weekly
chmod 700 /etc/cron.monthly
chmod 700 /etc/cron.d
chmod 700 /var/spool/cron
echo ' Patching GEN003120: Set owner of cron directories'
chown root /etc/cron.hourly
chown root /etc/cron.daily
chown root /etc/cron.weekly
chown root /etc/cron.monthly
chown root /etc/cron.d
chown root /var/spool/cron
chown root /etc/crontab
chown root /etc/anacrontab
echo ' Patching GEN003140: Set group grper of cron'
echo '                     directories'
chgrp root /etc/cron.hourly
chgrp root /etc/cron.daily
chgrp root /etc/cron.weekly
chgrp root /etc/cron.monthly
chgrp root /etc/cron.d
chgrp root /var/spool/cron
chgrp root /etc/crontab
chgrp root /etc/anacrontab
echo ' Patching GEN003180: Set cron log permissions'
chmod 600 /var/log/cron

if [ -e /var/log/cron ]; then
    echo ' Patching GEN003190: Remove ACLs from Cron Log'
    ACLOUT=`getfacl --skip-base /var/log/cron 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /var/log/cron
    fi
fi
echo ' Patching GEN003200: Seting cron.deny permissions'
chmod 600 /etc/cron.deny

if [ -a "/etc/at.allow" ]; then
    echo ' Patching GEN003245: Remove ACLs from /etc/at.allow'
    ACLOUT=`getfacl --skip-base /etc/at.allow 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/at.allow
    fi
fi
if [ -e "/etc/cron.allow" ]; then
    echo ' Patching GEN003250: /etc/cron.allow Group Ownership'
    CURGOWN=`stat -c %G /etc/cron.allow`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "cron" ]; then
        chgrp root /etc/cron.allow
    fi
fi
if [ -e "/etc/at.deny" ]; then
    echo ' Patching GEN003252: /etc/at.deny Permissions'
    find /etc/at.deny -perm /7177 -exec chmod u-xs,g-rwxs,o-rwxt {} \;
fi

if [ -a "/etc/at.deny" ]; then
    echo ' Patching GEN003255: Remove ACLs from /etc/at.deny'
    ACLOUT=`getfacl --skip-base /etc/at.deny 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/at.deny
    fi
fi
echo ' Patching GEN003260: Set owner and group owner of'
echo '                     the cron.deny file'
chown root:root /etc/cron.deny
if [ -e "/etc/cron.deny" ]; then
    echo ' Patching GEN003270: /etc/cron.deny Group Onwership'
    CURGOWN=`stat -c %G /etc/cron.deny`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "cron" ]; then
        chgrp root /etc/cron.deny
    fi
fi
echo ' Patching GEN003280: At Utility Accessibility'
if [ ! -f /etc/at.allow ]; then
    touch /etc/at.allow
    chown root:root /etc/at.allow
    chmod 600 /etc/at.allow
fi
if [ ! -f /etc/at.deny ]; then
    touch /etc/at.deny
    chown root:root /etc/at.deny
    chmod 600 /etc/at.allow
fi
echo ' Patching GEN003300: Set at.deny file'
echo -n > /etc/at.deny
for NAME in `cut -d: -f1 /etc/passwd`; do
        NAMEID=`id -u $NAME`
        if [ $NAMEID -lt 500 -a $NAME != 'root' ]; then
                echo $NAME >> /etc/at.deny
        fi
done;
echo ' Patching GEN003320: Only root may be in at.allow'
echo "root" > /etc/at.allow
echo ' Patching GEN003400: Set at directory permissions'
chmod 755 /var/spool/at/spool
echo ' Patching GEN003410: Remove ACLs from AT Daemon'
for ATFILE in /var/spool/cron/atjobs /var/spool/atjobs /var/spool/at; do
    if [ -a "$ATFILE" ]; then
        ACLOUT=`getfacl --skip-base $ATFILE 2>/dev/null`;
        if [ "$ACLOUT" != "" ]; then
            setfacl --remove-all $ATFILE
        fi
    fi
done
echo ' Patching GEN003420: Set owner and group owner of'
echo '                     the at directory'
chown root:root /var/spool/at/spool
echo ' Patching GEN003430: AT Daemon Group Ownership'
for ATFILE in /var/spool/cron/atjobs /var/spool/atjobs /var/spool/at; do
    if [ -a "$ATFILE" ]; then
        CURGOWN=`stat -c %G $ATFILE`;
        if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "daemon" -a "$CURGOWN" != "system" -a "$CURGOWN" != "cron" ]; then
            chgrp daemon $ATFILE
        fi
      fi
done
echo ' Patching GEN003460: Set owner and group owner of '
echo '                     the at.allow files'
chown root:root /etc/at.allow
if [ -e "/etc/at.allow" ]; then
    echo ' Patching GEN003470: /etc/at.allow Group Ownership'
    CURGOWN=`stat -c %G /etc/at.allow`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "cron" ]; then
        chgrp root /etc/at.allow
    fi
fi
echo ' Patching GEN003480: Set owner and group owner of'
echo '                     the at.deny file'
chown root:root /etc/at.deny
if [ -e "/etc/at.deny" ]; then
    echo ' Patching GEN003490: /etc/at.deny Group Ownership'
    CURGOWN=`stat -c %G /etc/at.deny`;
    if [ "$CURGOWN" != "root" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "cron" ]; then
        chgrp root /etc/at.deny
    fi
fi
echo ' Patching GEN003510: Disable kdump Service'
sysv-rc-conf --list | grep kdump | egrep '[2-5]:on' &>/dev/null
if [ $? -eq 0 ]; then
    service kdump stop
    sysv-rc-conf --level 2345 kdump off
fi
echo ' Patching GEN003540: Disable Executable Stack'
KERNEXEC=$( sysctl kernel.exec-shield | awk '{print $3}' )
KERNRAND=$( sysctl kernel.randomize_va_space | awk '{print $3}' )
if [ $KERNEXEC -ne 1 ]
  then
    echo " "  >> /etc/sysctl.conf
    echo "kernel.exec-shield = 1" >> /etc/sysctl.conf
    sysctl -p &> /dev/null
fi
if [ $KERNRAND -ne 2 ]
  then
    echo " "  >> /etc/sysctl.conf
    echo "kernel.randomize_va_space = 2" >> /etc/sysctl.conf
    sysctl -p &> /dev/null
fi
echo ' Patching GEN003581: Remove user control of network'
for NICCONF in `ls /etc/sysconfig/network-scripts/ifcfg*`; do
    grep USERCTL $NICCONF > /dev/null
    if [ $? -eq 0 ]; then
        sed -i 's/USERCTL=yes/USERCTL=no/g' $NICCONF
    else
        echo "USERCTL=no" >> $NICCONF
    fi
done
echo ' Patching GEN003600: Set network parameters'
sed -i "/net\.ipv4\.conf\.default\.rp_filter/ c\net.ipv4.conf.default.rp_filter = 1" /etc/sysctl.conf &>/dev/null
sed -i "/net\.ipv4\.conf\.default\.accept_source_route/ c\net.ipv4.conf.default.accept_source_route = 0" /etc/sysctl.conf &>/dev/null
`grep -q tcp_max_syn_backlog /etc/sysctl.conf`
if [ $? -ne 0 ]; then
    echo "net.ipv4.tcp_max_syn_backlog = 1280" >> /etc/sysctl.conf
fi
`grep -q icmp_echo_ignore_broadcasts /etc/sysctl.conf`
if [ $? -ne 0 ]; then
    echo "net.ipv4.icmp_echo_ignore_broadcasts = 1" >> /etc/sysctl.conf
fi
`grep -q disable_ipv6 /etc/sysctl.conf`
if [ $? -ne 0 ]; then
    echo "" >> /etc/sysctl.conf
    echo "net.ipv6.conf.all.disable_ipv6 = 1" >> /etc/sysctl.conf
fi
`grep -q NETWORKING_IPV6 /etc/sysconfig/network`
if [ $? -ne 0 ]; then
    echo "NETWORKING_IPV6=no" >> /etc/sysconfig/network
else
    sed -i "/NETWORKING_IPV6/s/yes/no/" /etc/sysconfig/network
fi
`grep -q IPV6INIT /etc/sysconfig/network`
if [ $? -ne 0 ]; then
    echo "IPV6INIT=no" >> /etc/sysconfig/network
else
    sed -i "/IPV6INIT/s/yes/no/" /etc/sysconfig/network
fi
`grep -q NOZEROCONF /etc/sysconfig/network`
if [ $? -ne 0 ]; then
    echo "NOZEROCONF=yes" >> /etc/sysconfig/network
else
    sed -i "/NOZEROCONF/s/no/yes/" /etc/sysconfig/network
fi
echo ' Patching GEN003660: Log autentication notice and'
echo '                     informational data'
`/bin/grep auth.notice /etc/syslog.conf | /bin/grep -q messages`
if [ $? -gt 0 ]; then
cat >> /etc/syslog.conf << EOF
auth.notice     /var/log/messages
EOF
fi
echo ' Patching GEN003700: Turn off unneeded services'
/sbin/sysv-rc-conf --list | grep -q xinetd
if [ $? -eq 0 ]; then
    /sbin/sysv-rc-conf xinetd off
    /sbin/service xinetd stop &> /dev/null
fi
if [ -e /etc/xinetd.conf ]; then
    echo ' Patching GEN003720: xinetd Files Ownership'
    find /etc/xinetd.conf /etc/xinetd.d/ ! -group root -exec chown root {} \; 2> /dev/null
fi
if [ -e /etc/xinetd.conf ]; then
    echo ' Patching GEN003730: xinetd Files Group Ownership'
    find /etc/xinetd.conf /etc/xinetd.d/ ! -group root ! -group bin ! -group sys -exec chgrp root {} \; 2> /dev/null
fi
echo ' Patching GEN003740: Set permissions for xinetd'
echo '                     configuration files.'
if [ -e /etc/xinetd.d ]; then
    chmod 755 /etc/xinetd.d
fi
if [ -e /etc/xinetd.conf ]; then
    chmod 440 /etc/xinetd.conf
fi
if [ -e "/etc/xinetd.conf" ]; then
    echo ' Patching GEN003745: Remove ACLs from xinetd Files'
    ACLOUT=`getfacl --skip-base /etc/xinetd.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/xinetd.conf
    fi
fi
if [ -d "/etc/xinetd.d" ]; then
    echo ' Patching GEN003750: xinetd Files Permissions'
    FILEPERMS=`stat -L --format='%04a' /etc/xinetd.d`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&0)) != "0" ] || [ $(($FILEGROUP&2)) != "0" ] || [ $(($FILEOTHER&2)) != "0" ]; then
        chmod u-s,g-ws,o-wt /etc/xinetd.d
    fi
fi

if [ -a "/etc/xinetd.d" ]; then
    echo ' Patching GEN003755: Remove ACLs from xinetd Files'
    ACLOUT=`getfacl --skip-base /etc/xinetd.d 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/xinetd.d
    fi
fi
echo ' Patching GEN003760: Set owner of services file'
chown root /etc/services
if [ -a "/etc/services" ]; then
    echo ' Patching GEN003770: /etc/services Group Ownership'
    CURGROUP=`stat -c %G /etc/services`;
    if [  "$CURGROUP" != "root" -a "$CURGROUP" != "bin" -a "$CURGROUP" != "sys" -a "$CURGROUP" != "system" ]; then
        chgrp root /etc/services
    fi
fi
if [ -a "/etc/services" ]; then
    echo ' Patching GEN003790: Remove ACLs from /etc/services'
    ACLOUT=`getfacl --skip-base /etc/services 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/services
    fi
fi
if [ -e /etc/xinetd.d/rsh ]; then
echo ' Patching GEN003820: Disable rshd Daemon'
    sed -i 's/[[:blank:]]*disable[[:blank:]]*=[[:blank:]]*no/        disable                 = yes/g' /etc/xinetd.d/rsh
fi
echo ' Patching GEN003825: Remove RSH Server Package'
apt-get purge -y rsh-server
RLOGIN='/etc/xinetd.d/rlogin'
if [ -a $RLOGIN ]; then
    echo ' Patching GEN003830: Disable rlogin Service'
    rm -f /etc/xinetd.d/rlogin
    service xinetd restart
fi
if [ -e /etc/xinetd.d/ ]; then
    echo ' Patching GEN003850: Disable Telnet Daemon'
    for TELNETCONF in `ls /etc/xinetd.d/ | grep telnet`; do
        if [ -e $TELNETCONF ]; then
            sed -i 's/[[:blank:]]*disable[[:blank:]]*=[[:blank:]]*no/        disable                 = yes/g' $TELNETCONF
        fi
    done
fi
echo ' Patching GEN003865: Remove Network Anaylzers'
for NETPKG in wireshark wireshark-gnome nc tcpdump nmap; do
    apt-get purge -y $NETPKG
done
find / -name wireshark -o -name wireshark -o -name wireshark-gnome -o -name nc -o -name tcpdump -o -name snoop -o -name tshark -o -name nmap -exec rm -f {} \;
echo ' Patching GEN003920: Printer Ownership '
if [ -a "/etc/cups/printers.conf" ]; then
  CUROWN=`stat -c %U /etc/cups/printers.conf`;
  if [ "$CUROWN" != "root" ]; then
      chown root /etc/cups/printers.conf
  fi
fi
echo ' Patching GEN003940: Printer Permissions'
if [ -a "/etc/cups/printers.conf" ]; then
    FILEPERMS=`stat -L --format='%04a' /etc/cups/printers.conf`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&1)) != "0" ] || [ $(($FILEOTHER&3)) != "0" ]; then
        chmod u-xs,g-xs,o-wxt /etc/cups/printers.conf
    fi
fi
if [ -a "/etc/cups/printers.conf" ];then
    echo ' Patching GEN003950: Remove ACLs from printers.conf'
    ACLOUT=`getfacl --skip-base /etc/cups/printers.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/cups/printers.conf
    fi
fi
echo ' Patching GEN003960: Set traceroute comand owner'
chown root /bin/traceroute
echo ' Patching GEN003980: Set group owner of the'
echo '                     traceroute command'
chgrp root /bin/traceroute
echo ' Patching GEN004000: Limit access to traceroute to'
echo '                     root user only.'
chmod 700 /bin/traceroute
if [ -a "/bin/traceroute" ]; then
    echo ' Patching GEN004010: Remove ACLs from traceroute'
    ACLOUT=`getfacl --skip-base /bin/traceroute 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /bin/traceroute
    fi
fi
echo ' Patching GEN004360: Set owner of aliases file'
chown root /etc/aliases
if [[ -e /etc/aliases || -e /etc/aliases.db ]]; then
    echo ' Patching GEN004370: /etc/aliases Group Ownership'
fi
if [ -a "/etc/aliases" ]; then
    CURGROUP=`stat -c %G /etc/aliases`;
    if [  "$CURGROUP" != "root" ]; then
        chgrp root /etc/aliases
    fi
fi
if [ -a "/etc/aliases.db" ]; then
    CURGROUP=`stat -c %G /etc/aliases.db`;
    if [  "$CURGROUP" != "smmsp" ]; then
        chgrp postfix /etc/aliases.db
    fi
fi
if [[ -e /etc/aliases || -e /etc/aliases.db ]]; then
    echo ' Patching GEN004390: Remove ACLs from /etc/aliases'
fi
if [ -a "/etc/aliases" ]; then
    ACLOUT=`getfacl --skip-base /etc/aliases 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/aliases
    fi
fi
if [ -a "/etc/aliases.db" ]; then
    ACLOUT=`getfacl --skip-base /etc/aliases.db 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/aliases.db
    fi
fi
echo ' Patching GEN004480: Set owner of mail log file'
chown root /var/log/maillog
echo ' Patching GEN004500: Set mail log file permissions'
chmod 640 /var/log/maillog
MAILLOG=$( egrep "(\*.crit|mail\.[^n][^/]*)" /etc/syslog.conf|sed 's/^[^/]*//' )
if [ -a $MAILLOG ]; then
    echo ' Patching GEN004510: Remove ACLs from Mail Log'
    ACLOUT=`getfacl --skip-base $MAILLOG 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all $MAILLOG
    fi
fi
echo ' Patching GEN004540: Disable sendmail help.'
if [ -e /etc/mail/helpfile ]; then
    mv /etc/mail/helpfile /etc/mail/helpfile.bak
    echo "" > /etc/mail/helpfile
fi
echo ' Patching GEN004560: Set sendmail greeting message'
if [ -e /etc/mail/sendmail.cf ]; then
sed -i '/SmtpGreetingMessage/ c\
O SmtpGreetingMessage= Mail Server Ready ; $b' /etc/mail/sendmail.cf
fi
if [ -a '/etc/mail/sendmail.mc' ]; then
    echo ' Patching GEN004710: Restrict Mail Relaying'
    RELAYON=$( grep -i promiscuous_relay /etc/mail/sendmail.mc | wc -l )
    SENDMAILON=$( service sendmail status | grep -c running )
    if [ $RELAYON -ne 0 ]; then
        sed "/promiscuous_relay/d" /etc/mail/sendmail.mc
        if [ $SENDMAILON -eq 1 ]; then
            service sendmail restart &> /dev/null
        fi
    fi
fi
echo ' Patching GEN004800: Disable Unencrypted Services'
echo '                     (Telnet, FTP)'
for SERVICE in 'telnet gssftp vsftpd'; do
    sysv-rc-conf --list $SERVICE 2> /dev/null | egrep 'on' > /dev/null
    if [ $? -eq 0 ]; then
            sysv-rc-conf $SERVICE off > /dev/null
            if [ "$SERVICE" = 'vsftpd' ]; then
                service $SERVICE stop > /dev/null
            fi
    fi
done
echo ' Patching GEN004880: Create ftpusers file'
touch /etc/ftpusers
echo ' Patching GEN004900: Add system users to ftpusers'
echo -n > /etc/ftpusers
for NAME in `cut -d: -f1 /etc/passwd`; do
    NAMEID=`id -u $NAME`
    if [ $NAMEID -lt 500 ]; then
        echo $NAME >> /etc/ftpusers
    fi
done;
echo ' Patching GEN004920: Set owner of ftpusers file'
chown root /etc/ftpusers
if [[ -e /etc/vsftpd/ftpusers || -e /etc/vsftpd.ftpusers || -e /etc/ftpusers ]]; then
    echo ' Patching GEN004930: ftpusers Ownership'
    for FTPFILE in /etc/vsftpd/ftpusers /etc/vsftpd.ftpusers /etc/ftpusers; do
        if [ -a "$FTPFILE" ]; then
                CURGROUP=`stat -c %G $FTPFILE`;
                if [  "$CURGROUP" != "root" -a "$CURGROUP" != "bin" -a "$CURGROUP" != "sys" -a "$CURGROUP" != "system" ]; then
                chgrp root $FTPFILE
                fi
        fi
    done
fi
echo ' Patching GEN004940: Set ftpusers permissions'
chmod 640 /etc/ftpusers
if [[ -e /etc/vsftpd/ftpusers || -e /etc/vsftpd.ftpusers || -e /etc/ftpusers ]]; then
    echo ' Patching GEN004950: Remove ACLs from ftpusers'
    for FTPFILE in /etc/ftpusers /etc/vsftpd.ftpusers /etc/vsftpd/ftpusers; do
        if [ -a "$FTPFILE" ]; then
            ACLOUT=`getfacl --skip-base $FTPFILE 2>/dev/null`;
            if [ "$ACLOUT" != "" ]; then
                setfacl --remove-all $FTPFILE
            fi
        fi
    done
fi
if [ -a /etc/xinetd.d/tftp ]; then
TFTPACCOUNT=$(cat /etc/passwd | grep -i tftp| wc -l)
echo ' Patching GEN005120: TFTPD Account'
    if [ $TFTPACCOUNT -ne 1 ]; then
        useradd -r -s /bin/false -c "TFTPD Account - GEN005120" -d /tftpboot/ tftp
        usermod -L tftp
    fi
fi
echo ' Patching GEN001900: .Xauthority File Permissions'
find / -name *.xauth -o -name *.Xauthority -perm /7177 -exec chmod u-xs,g-rwxs,o-rwxt {} \;
echo ' Patching GEN005190: Remove ACLs from .Xauthority'
XAUTHFILE=$( find / -name *.xauth 2>/dev/null )
XAUTHORITYFILE=$(find / -name *.Xauthority 2>/dev/null )
for line in $XAUTHFILE; do
    if [ -a $line ]; then
        ACLOUT=`getfacl --skip-base $line 2>/dev/null`;
        if [ "$ACLOUT" != "" ]; then
            setfacl --remove-all $line
        fi
    fi
done
for line in $XAUTHORITYFILE; do
    if [ -a $line ]; then
        ACLOUT=`getfacl --skip-base $line 2>/dev/null`;
        if [ "$ACLOUT" != "" ]; then
            setfacl --remove-all $line
        fi
    fi
done
sysv-rc-conf --list uucp 2>/dev/null | grep 'on' > /dev/null
if [ $? -eq 0 ]; then
echo ' Patching GEN005280: Disable UUCP Daemon'
    sysv-rc-conf uucp off
    service xinetd restart
fi
SNMPCONF=/etc/snmp/snmpd.conf
if [ -e $SNMPCONF ]; then
    echo ' Patching GEN005305: Only SNMPv3 Allowed'
    if [ $V1VAR -ne 0 ]; then
    fi
    if [ $V2CVAR -ne 0 ]; then
    fi
    if [ $COMMVAR -ne 0 ]; then
    fi
    if [ $COM2VAR -ne 0 ]; then
    fi
fi
if [ -e /etc/snmp/snmpd.conf ]; then
    grep 'createUser' /etc/snmp/snmpd.conf | grep 'MD5' >/dev/null
    if [ $? -eq 0 ]; then

        echo ' Patching GEN005306: SNMP FIPS 140-2 Ecryption'

        sed -i 's/^\(createUser.*\)MD5\(.*\)/\1SHA\2/g' /etc/snmp/snmpd.conf
        echo ""
        echo "   Please review /etc/snmp/snmpd.conf for manual changes"
        echo "   to the createUser option it should use SHA and AES in"
        echo "   the following format:"
        echo ""
        echo "         createUser <user> SHA passwd AES encyption"
        echo ""
    fi
fi
if [ -e /etc/snmp/snmpd.conf ]; then
    grep 'createUser' /etc/snmp/snmpd.conf | grep 'MD5' >/dev/null
    if [ $? -eq 0 ]; then

        echo ' Patching GEN005307: SNMP FIPS 140-2 Ecryption'

        sed -i 's/^\(createUser.*\)DES\(.*\)/\1AES\2/g' /etc/snmp/snmpd.conf
        echo ""
        echo "   Please review /etc/snmp/snmpd.conf for manual changes"
        echo "   to the createUser option it should use SHA and AES in"
        echo "   the following format:"
        echo ""
        echo "         createUser <user> SHA passwd AES encyption"
        echo ""
    fi
fi
echo ' Patching GEN005320: SNMP Configuration Permissions'
SNMPDFILES=$( find / -name snmpd.conf -print )
for line in $SNMPDFILES; do
    if [ -a $line ]; then
    FILEPERMS=`stat -L --format='%04a' $line`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
        if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&7)) != "0" ] || [ $(($FILEOTHER&7)) != "0" ]; then
          chmod u-xs,g-rwxs,o-rwxt $line
        fi
    fi
done
echo ' Patching GEN005340: MIB File Permissions'
find / -name *.mib -type f -exec chmod u-xs,g-wxs,o-rwxt {} \;
if  [ -d /usr/share/snmp/mibs/ ]; then
    find /usr/share/snmp/mibs/ -type f -name '*.txt' -exec chmod u-xs,g-wxs,o-rwxt {} \;
fi
MIBFILES=$( find / -name *.mib -print )
if [ ! -z $MIBFILES ]; then
    echo ' Patching GEN005350: Remove ACLs from MIB Files'
    for LINE in $MIBFILES; do
        if [ -a $LINE ];  then
            ACLOUT=`getfacl --skip-base $LINE 2>/dev/null`
            if [ "$ACLOUT" != "" ]; then
                setfacl --remove-all $LINE
            fi
        fi
    done
fi
echo ' Patching GEN005360: Set owner of snmpd.conf file'
if [ -e /etc/snmp/snmpd.conf ]; then
chown root:sys /etc/snmp/snmpd.conf
fi
SNMPDFILES=$( find / -name snmpd.conf -print )
if [ ! -z $SNMPDFILES ]; then
    echo ' Patching GEN005365: snmpd.conf Group Ownership'
    for LINE in $SNMPDFILES; do
        if [ -a $LINE ]; then
            CURGOWN=`stat -c %G $LINE`
            if [ "$CURGOWN" != "root" ]; then
                chgrp root $LINE
            fi
        fi
    done
fi
SNMPDFILES=$( find / -name snmpd.conf -print )
if [ ! -z $SNMPDFILES ]; then
    echo ' Patching GEN005375: Remove ACLs from snmpd.conf'
    for LINE in $SNMPDFILES; do
        if [ -a $LINE ]; then
            ACLOUT=`getfacl --skip-base $LINE 2>/dev/null`
            if [ "$ACLOUT" != "" ]; then
                setfacl --remove-all $LINE
            fi
            fi
    done
fi
if [ -a "/etc/syslog.conf" ]; then
    echo ' Patching GEN005390: syslog.conf Permissions'
    FILEPERMS=`stat -L --format='%04a' /etc/syslog.conf`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&3)) != "0" ] || [ $(($FILEOTHER&7)) != "0" ]; then
        chmod u-xs,g-wxs,o-rwxt /etc/syslog.conf
    fi
fi
echo ' Patching GEN005400: Set syslog.conf permissions'
chown root /etc/syslog.conf
chmod 640 /etc/syslog.conf
echo ' Patching GEN005420: Set group owner of syslog.conf'
chgrp root /etc/syslog.conf
if [ -e '/etc/sysconfig/syslog' ]; then
echo ' Patching GEN005480: Syslog Accepts Remote Messages'
    grep 'SYSLOGD_OPTIONS' /etc/sysconfig/syslog | grep '\-r' > /dev/null
    if [ $? -eq 0 ]; then
        sed -i 's/-r//g' /etc/sysconfig/syslog
    fi
fi
echo ' Patching GEN005501: Ensure SSHv2 is used on client'
grep -q Protocol /etc/ssh/ssh_config 2>/dev/null
if [ $? -eq 0 ]; then
    egrep '^Protocol.*1' /etc/ssh/ssh_config 2>/dev/null
    if [ $? -eq 0 ]; then
        sed -i "/^Protocol/ c\Protocol 2" /etc/ssh/ssh_config
    fi
else
    echo "Protocol 2" >> /etc/ssh/ssh_config
fi
grep ',.*es.*-cbc' /etc/ssh/ssh_config > /dev/null
if [ $? -eq 0 ]; then
    echo ' Patching GEN005505: Removing CBC Ciphers from SSHD'
    sed -i 's/,aes128-cbc//g' /etc/ssh/ssh_config
    sed -i 's/,3des-cbc//g' /etc/ssh/ssh_config
    sed -i 's/,aes192-cbc//g' /etc/ssh/ssh_config
    sed -i 's/,aes256-cbc//g' /etc/ssh/ssh_config
fi
grep ',.*es.*-cbc' /etc/ssh/sshd_config > /dev/null
if [ $? -eq 0 ]; then
    echo ' Patching GEN005506: Removing CBC Ciphers from SSHD'
    sed -i 's/,aes128-cbc//g' /etc/ssh/sshd_config
    sed -i 's/,3des-cbc//g' /etc/ssh/sshd_config
    sed -i 's/,aes192-cbc//g' /etc/ssh/sshd_config
    sed -i 's/,aes256-cbc//g' /etc/ssh/sshd_config
fi
grep -q "hmac-sha" /etc/ssh/sshd_config 2>/dev/null
if [ $? -ne 0 ]; then
    echo ' Patching GEN005507: Add MACs hmac-sha1 to SSHD'
    echo " " >> /etc/ssh/sshd_config
    echo "MACs hmac-sha2-512 hmac-sha2-256" >> /etc/ssh/sshd_config
fi
grep ',.*es.*-cbc' /etc/ssh/sshd_config > /dev/null
if [ $? -eq 0 ]; then
    echo ' Patching GEN005510: Removing CBC Ciphers from SSHD'
    sed -i 's/,aes128-cbc//g' /etc/ssh/sshd_config
    sed -i 's/,3des-cbc//g' /etc/ssh/sshd_config
    sed -i 's/,aes192-cbc//g' /etc/ssh/sshd_config
    sed -i 's/,aes256-cbc//g' /etc/ssh/sshd_config
fi
grep ',.*es.*-cbc' /etc/ssh/ssh_config > /dev/null
if [ $? -eq 0 ]; then
    echo ' Patching GEN005511: Removing CBC Ciphers from SSH'
    sed -i 's/,aes128-cbc//g' /etc/ssh/ssh_config
    sed -i 's/,3des-cbc//g' /etc/ssh/ssh_config
    sed -i 's/,aes192-cbc//g' /etc/ssh/ssh_config
    sed -i 's/,aes256-cbc//g' /etc/ssh/ssh_config
fi
grep -q "MACs hmac-sha1" /etc/ssh/ssh_config 2>/dev/null
if [ $? -ne 0 ]; then
    echo ' FIPS 140-2 MACs to SSH'
    echo " " >> /etc/ssh/ssh_config
    echo "MACs hmac-sha2-512,hmac-sha2-256,hmac-sha1" >> /etc/ssh/ssh_config
fi
echo ' Patching GEN005522: SSH Public Key Permissions'
find /etc/ssh -type f -name '*key.pub' -exec chmod u-xs,g-wxs,o-wxt {} \;
echo ' Patching GEN005523: SSH Private Key Permissions'
find /etc/ssh -type f -name '*key' -exec chmod u-xs,g-rwxs,o-rwxt {} \;
echo ' Patching GEN005536: Enable Strict Mode SSHD'
if [ $WHATMODE -eq 0 ]; then
    echo "StrictModes yes" >> /etc/ssh/sshd_config
else
    if [ $MODECORRECT -eq 1 ]; then
        sed -i 's/StrictModes no/StrictModes yes/g' /etc/ssh/sshd_config
    fi
fi
echo ' Patching GEN005537: PrivlageSeperation on SSHD'
if [ $USERPRIV -eq 0 ]; then
    echo "UsePrivilegeSeparation yes" >> /etc/ssh/sshd_config
else
    if [ $MODECORRECT -eq 1 ]; then
        sed -i 's/UsePrivilegeSeparation no/UsePrivilegeSeparation yes/g' /etc/ssh/sshd_config
    fi
fi
echo ' Patching GEN005538: Disable rhosts RSA auth on SSHD'
if [ $USERPRIV -eq 0 ]; then
    echo "RhostsRSAAuthentication no" >> /etc/ssh/sshd_config
else
    if [ $MODECORRECT -eq 1 ]; then
        sed -i 's/RhostsRSAAuthentication yes/RhostsRSAAuthentication no/g' /etc/ssh/sshd_config
    fi
fi
echo ' Patching GEN005537: Enable Compression after'
echo '                     authentication in SSHD'
if [ $COMP -eq 0 ]; then
    echo "Compression delayed" >> /etc/ssh/sshd_config
else
    if [ $MODECORRECT -ne 1 ]; then
        sed -i 's/Compression.*/Compression delayed/g' /etc/ssh/sshd_config
    fi
fi
echo ' Patching GEN005550: Legal Banner on SSHD'
grep -i banner /etc/ssh/sshd_config > /dev/null
if [ $? -eq 0 ]; then
    if [ $? -ne 0 ]; then
    fi
else
    echo "Banner /etc/issue" >> /etc/ssh/sshd_config
fi
echo ' Patching GEN005590: Disable Routing Protocol Daemons'
for SERVICE in bgpd ospf6d ospfd ripd ripngd zebra; do
    sysv-rc-conf --list $SERVICE 2>/dev/null | grep ':on' > /dev/null
    if [ $? -eq 0 ]; then
        service $SERVICE stop &>/dev/null
        sysv-rc-conf $SERVICE off &>/dev/null
    fi
done
echo ' Patching GEN005600: Disable IP forwarding'
sed -i "/net\.ipv4\.ip_forward/ c\
net.ipv4.ip_forward = 0" /etc/sysctl.conf
echo ' Patching GEN005740: Set owner of export config file'
chown root /etc/exports
echo ' Patching GEN005750: /etc/exports Group Ownership'
if [ -a "/etc/exports" ]; then
    CURGROUP=`stat -c %G /etc/exports`;
    if [  "$CURGROUP" != "root" ]; then
        chgrp root /etc/exports
    fi
fi
echo ' Patching GEN005770: Remove ACLs from /etc/exports'
if [ -a "/etc/exports" ]; then
    ACLOUT=`getfacl --skip-base /etc/exports 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/exports
    fi
fi
echo ' Patching GEN005800: Exported Files Ownership '
EXPORTDIRS=$( cat /etc/exports | awk '{print $1}' )
for line in $EXPORTDIRS; do
    if [ -a $line ]; then
            CUROWN=`stat -c %U $line`;

            if [ "$CUROWN" != "root" ]; then
                    chown root $line
            fi
        fi
done
echo ' Patching GEN005810: NFS Exports Group Ownership'
EXPORTDIRS=$( cat /etc/exports | awk '{print $1}' )
for line in $EXPORTDIRS; do
    if [ -a $line ]; then
        CURGOWN=`stat -c %G $line`
        if [ "$CURGOWN" != "root" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "system" ]; then
            chgrp root $line
        fi
    fi
done
echo ' Patching GEN005840: NFS Filesystem Access'
egrep -v 'r[wo][,)]' /etc/exports > /dev/null
if [ $? -eq 0 ]; then
    sed -i -e '/r[wo][,)]/! s/\(.*\))/\1,ro\)/g' /etc/exports
    exportfs -a
fi
echo ' Patching GEN005880: Remove Root Access from NFS'
grep -v 'root_squash' /etc/exports > /dev/null
if [ $? -eq 0 ]; then
  sed -i -e '/root_squash/! s/\(.*\))/\1,root_squash\)/g' /etc/exports
  exportfs -a
fi
grep no_root_squash /etc/exports > /dev/null
if [ $? -eq 0 ]; then
  sed -i -e 's/no_root_squash/root_squash/g' /etc/exports
fi
echo ' Patching GEN006100: Set owner of smb.conf'
if [ -e /etc/samba/smb.conf ]; then
    chown root /etc/samba/smb.conf
fi
echo ' Patching GEN006120: Set group owner of smb.conf'
if [ -e /etc/samba/smb.conf ]; then
    chgrp root /etc/samba/smb.conf
fi
if [ -a "/etc/samba/smb.conf" ]; then
    echo ' Patching GEN006150: Remove ACLs from smb.conf'
    ACLOUT=`getfacl --skip-base /etc/samba/smb.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/samba/smb.conf
    fi
fi
echo ' Patching GEN006160: Set owner of smbpasswd'
if [ -e /usr/bin/smbpasswd ]; then
    chown root /usr/bin/smbpasswd
fi
echo ' Patching GEN006180: Set group owner of smbpasswd'
if [ -e /usr/bin/smbpasswd ]; then
    chgrp root /usr/bin/smbpasswd
fi
echo ' Patching GEN006200: Set permissions for smbpasswd'
if [ -e /usr/bin/smbpasswd ]; then
    chmod 600 /usr/bin/smbpasswd
fi
if [ -a "/etc/samba.secrets.tdb" ]; then
    echo ' Patching GEN006210: Remove ACLs from Samba Files'
    ACLOUT=`getfacl --skip-base /etc/samba.secrets.tdb 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/samba.secrets.tdb
    fi
fi
if [ -a "/etc/samba/passdb.tdb" ]; then
    ACLOUT=`getfacl --skip-base /etc/samba/passdb.tdb 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/samba/passdb.tdb
    fi
fi
SECURITYSHARE=$( grep -i security /etc/samba/smb.conf | grep -i share | grep -i "=" | wc -l )
if [ $SECURITYSHARE -ne 0 ]; then
    echo ' Patching GEN006225: Samba Security Configuration'
    sed -i 's/[[:blank:]]*security[[:blank:]]*=[[:blank:]]*share/        security = user/g' /etc/samba/smb.conf
fi
if [ -e /etc/samba/smb.conf ]; then
    echo ' Patching GEN006150: Enable Samba Encryption'
    ENCRYPTPASS=$( grep -i 'encrypt passwords' /etc/samba/smb.conf | wc -l )
    if [ $ENCRYPTPASS -eq 0 ];  then
        sed -i 's/\[global\]/\[global\]\n\n\tencrypt passwords = yes/g' /etc/samba/smb.conf
    else
        sed -i 's/[[:blank:]]*encrypt[[:blank:]]passwords[[:blank:]]*=[[:blank:]]*no/        encrypt passwords = yes/g' /etc/samba/smb.conf
    fi
fi
echo ' Patching GEN006260: Set hosts.nntp permissions'
if [ -e /etc/news/hosts.nntp ]; then
    chmod 600 /etc/news/hosts.nntp
fi
if [ -a "/etc/news/incoming.conf" ];then
    echo ' Patching GEN006270: Remove ACLs from incoming.conf'
    ACLOUT=`getfacl --skip-base /etc/news/incoming.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/news/incoming.conf
    fi
fi
echo ' Patching GEN006280: Set hosts.nnt.nolimit'
echo '                     permissions'
if [ -e /etc/news/hosts.nntp.nolimit ]; then
    chmod 600 /etc/news/hosts.nntp.nolimit
fi
if [ -a "/etc/news/innfeed.conf" ]; then
    echo ' Patching GEN006290: Remove ACLs from innfeed.conf '
    ACLOUT=`getfacl --skip-base /etc/news/innfeed.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/news/innfeed.conf
    fi
fi
echo ' Patching GEN006300: Set nnrp.access permissions'
if [ -e /etc/news/nnrp.access ]; then
    chmod 600 /etc/news/nnrp.access
fi
if [ -a "/etc/news/readers.conf" ]; then
    echo ' Patching GEN006310: Remove ACLs from readers.conf'
    ACLOUT=`getfacl --skip-base /etc/news/readers.conf 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/news/readers.conf
    fi
fi
echo ' Patching GEN006320: Set passwd.nntp permissions'
if [ -e /etc/news/passwd.nntp ]; then
    chmod 600 /etc/news/passwd.nntp
fi
if [ -a "/etc/news/passwd.nntp" ]; then
    echo ' Patching GEN006330: Remove ACLs from passwd.nntp'
    ACLOUT=`getfacl --skip-base /etc/news/passwd.nntp 2>/dev/null`;
    if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all /etc/news/passwd.nntp
    fi
fi
echo ' Patching GEN006340: Set owner of /etc/news files'
if [ -d /etc/news/ ]; then
    chown -R root /etc/news/*
fi
echo ' Patching GEN006360: Set group owner of /etc/news'
echo '                     files'
if [ -d /etc/news/ ]; then
    chgrp -R root /etc/news/*
fi
sysv-rc-conf --list ypbind 2>/dev/null | egrep -e '[2345]:on'
if [ $? -eq 0 ]; then
    echo ' Patching GEN006400: Disable NIS'
    service ypbind stop > /dev/null
    sysv-rc-conf --level 2345 ypbind off
fi
if [ $? -eq 0 ]; then
    echo ' Patching GEN006420: NIS Maps Domain Names'
    DNAME=`cat /dev/urandom | tr -cd "[:upper:]" | head -c ${1:-10}`
    grep 'DOMAINNAME=' /etc/sysconfig/network > /dev/null
    if [ $? -ne 0 ]; then
        echo "DOMAINNAME=$DNAME" >> /etc/sysconfig/network
    else
        sed -i -e "s/DOMAINNAME=.*/DOMAINNAME=${DNAME}/g" /etc/sysconfig/network
    fi
    grep 'NISDOMAIN=' /etc/sysconfig/network > /dev/null
    if [ $? -ne 0 ]; then
        echo "NISDOMAIN=$DNAME" >> /etc/sysconfig/network
    else
        sed -i -e "s/NISDOMAIN=.*/NISDOMAIN=${DNAME}/g" /etc/sysconfig/network
    fi
fi
echo ' Patching GEN006520: Set security tool and database'
echo '                     permissions'
chmod 740 /etc/rc.d/init.d/iptables
chmod 740 /sbin/iptables
IPV6=$( cat /etc/sysconfig/network|grep "NETWORKING_IPV6=yes" | wc -l )
grep NETWORKING_IPV6 /etc/sysconfig/network > /dev/null
if [ $? -eq 0 ]; then
    if [ $IPV6 -ne 0 ]; then
        sed -i 's/NETWORKING_IPV6=yes/NETWORKING_IPV6=no/g' /etc/sysconfig/network
    fi
else
    echo "NETWORKING_IPV6=no" >> /etc/sysconfig/network
fi
sysv-rc-conf --list ip6tables | grep ':on' > /dev/null
if [ $? -eq 0 ]; then
    service ip6tables stop &>/dev/null
    sysv-rc-conf ip6tables off &>/dev/null
    rmmod ipv6 &>/dev/null
fi
echo ' Patching GEN007700: Disable IPv6 to IPv4 Tunnels'
for TUNDEV in `ip tun list | awk -F ':' '/remote any/ && /ipv6\/ip/{print $1}'`;do
    ip link set $TUNDEV down &>/dev/null
    ip tun del name $TUNDEV &>/dev/null
done
grep 'IPV6_AUTOTUNNEL' /etc/sysconfig/network > /dev/null
if [ $? -eq 0 ]; then
    grep 'IPV6_AUTOTUNNEL=yes' /etc/sysconfig/network > /dev/null
    if [ $? -eq 0 ]; then
        sed -i -e 's/IPV6_AUTOTUNNEL=yes/IPV6_AUTOTUNNEL=no/g' /etc/sysconfig/network
    fi
else
    echo "IPV6_AUTOTUNNEL=no" >> /etc/sysconfig/network
fi
echo ' Patching GEN007820: Disable IP Tunnels'
for TUNDEV in `ip tun list | awk -F ':' '{print $1}'`; do
    ip link set $TUNDEV down &>/dev/null
    ip tun del name $TUNDEV &>/dev/null
done
echo ' Patching GEN007850: Disable Dynamic DNS w/ DHCP'
if [ ! -f /etc/dhclient.conf ]; then
    touch /etc/dhclient.conf
    cat > /etc/dhclient.conf << EOF
append domain-name ".mil";
options ndots 2;
timeout 5;
do-forward-updates false;
EOF
fi
FORWARDUP=$( grep do-forward-updates /etc/dhclient.conf | wc -l )
if [ $FORWARDUP -eq 0 ];  then
    echo "do-forward-updates false;" >> /etc/dhclient.conf
else
    egrep "do-forward-updates.*true;" /etc/dhclient.conf > /dev/null
    if [ $? -eq 0 ]; then
        sed -i -e 's/do-forward-updates.*$/do-forward-updates false;/' /etc/dhclient.conf
    fi
fi

if [ -e /etc/sysconfig/ip6tables ]; then
    grep 'icmpv6 \-d ff02::1' /etc/sysconfig/ip6tables > /dev/null
    if [ $? -ne 0 ]; then
    echo ' Patching GEN007950: Disable IPv6 ICMP Echos'

        grep 'RH-Firewall-1-INPUT' /etc/sysconfig/ip6tables > /dev/null
        if [ $? -eq 0 ]; then
            sed -i -e 's/\(:RH-Firewall-1-INPUT.*$\)/\1\n-A INPUT -p icmpv6 -d ff02::1 --icmpv6-type 128 -j DROP/g' /etc/sysconfig/ip6tables
        else
            sed -i -e 's/\(:OUTPUT.*$\)/\1\n-A INPUT -p icmpv6 -d ff02::1 --icmpv6-type 128 -j DROP/g' /etc/sysconfig/ip6tables
        fi
    fi
fi
echo ' Patching GEN007960: Remove User Execute Permissions'
echo '                     from /usr/bin/ldd'
find /usr/bin/ldd -type f | xargs chmod 0500
chown root:root /usr/bin/ldd
RUNFIX=0
if [ $? -eq 0 ]; then
    RUNFIX=1
fi
if [ $? -eq 0 ]; then
    RUNFIX=1
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN007980: Enable LDAP for FIPS 140-2'
    if [ $RUNFIX -eq 1 ]; then
        if [ -e /etc/ldap.conf ]; then
            grep '^ssl ' /etc/ldap.conf > /dev/null
            if [ $? -eq 0 ]; then
                grep '^ssl start_tls$' /etc/ldap.conf > /dev/null
                if [ $? -ne 0 ]; then
                    sed -i -e 's/^ssl .*/ssl start_tls/g' /etc/ldap.conf
                fi
            else
                echo "ssl start_tls" >> /etc/ldap.conf
            fi
        fi
    fi
fi
RUNFIX=0
if [ $? -eq 0 ];then
    RUNFIX=1
fi
if [ $? -eq 0 ]; then
    RUNFIX=1
fi
if [ $RUNFIX -eq 1 ]; then
    if [ -e /etc/ldap.conf ]; then

        echo ' Patching GEN008020: Configure tls_checkpeer in LDAP'

        grep '^tls_checkpeer ' /etc/ldap.conf > /dev/null
        if [ $? -eq 0 ]; then
            grep '^tls_checkpeer yes$' /etc/ldap.conf > /dev/null
            if [ $? -ne 0 ]; then
                sed -i -e 's/^tls_checkpeer .*/tls_checkpeer yes/g' /etc/ldap.conf
            fi
        else
            echo "tls_checkpeer yes" >> /etc/ldap.conf
        fi
    fi
fi
RUNFIX=0
if [ $? -eq 0 ]; then
    RUNFIX=1
fi
if [ $? -eq 0 ]; then
    RUNFIX=1
fi
if [ $RUNFIX -eq 1 ]; then
    if [ -e /etc/ldap.conf ]; then

        echo ' Patching GEN008040: Configure tls_crlceck in LDAP'

        grep '^tls_crlcheck ' /etc/ldap.conf > /dev/null
        if [ $? -eq 0 ]; then
            grep '^tls_crlcheck all$' /etc/ldap.conf > /dev/null
            if [ $? -ne 0 ]; then
                sed -i -e 's/^tls_crlcheck .*/tls_crlcheck all/g' /etc/ldap.conf
            fi
        else
            echo "tls_crlcheck all" >> /etc/ldap.conf
        fi
    fi
fi
if [ -a "/etc/ldap.conf" ]; then
    echo ' Patching GEN008060: ldap.conf Permissions'
    FILEPERMS=`stat -L --format='%04a' /etc/ldap.conf`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&3)) != "0" ] || [ $(($FILEOTHER&3)) != "0" ]; then
        chmod u-xs,g-wxs,o-wxt /etc/ldap.conf
    fi
fi
if [ -a "/etc/ldap.conf" ]; then
    echo ' Patching GEN008080: ldap.conf Ownership'
    CUROWN=`stat -c %U /etc/ldap.conf`;
    if [ "$CUROWN" != "root" ]; then
        chown root /etc/ldap.conf
    fi
fi
if [ -a "/etc/ldap.conf" ]; then
    echo ' Patching GEN008100: ldap.conf Group Ownership'
    CURGROUP=`stat -c %G /etc/ldap.conf`;
    if [  "$CURGROUP" != "root" -a "$CURGROUP" != "bin" -a "$CURGROUP" != "sys" -a "$CURGROUP" != "system" ]; then
        chgrp root /etc/ldap.conf
    fi
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008140: LDAP TLS Certificate Ownership'
    TLSCERTS=$(  grep -i '^tls_cacert' /etc/ldap.conf | awk '{print $2}' )
    for FILEORDIR in $TLSCERTS; do
        find $FILEORDIR ! -user root -exec chown root {} \;
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008140: LDAP TLS Certificate Group'
    echo '                     Ownership'
    TLSCERTS=$(  grep -i '^tls_cacert' /etc/ldap.conf | awk '{print $2}' )
    for FILEORDIR in $TLSCERTS; do
        find $FILEORDIR ! -group root ! -group bin ! -group sys -exec chgrp root {} \; 2>/dev/null
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008180: LDAP TLS Certificate Permission'
    TLSCERTS=$(  grep -i '^tls_cacert' /etc/ldap.conf | awk '{print $2}' )
    for FILEORDIR in $TLSCERTS; do
        find $FILEORDIR -perm /7133 -type f -exec chmod u-xs,g-wxs,o-wxt {} \; 2>/dev/null
        find $FILEORDIR -perm /7022 -type d -exec chmod u-s,g-ws,o-wt {} \; 2>/dev/null
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008200: Remove ACLs from LDAP TLS'
    echo '                     Certificates'
    TLSCERTS=$(  grep -i '^tls_cacert' /etc/ldap.conf | awk '{print $2}' )
    for FILEORDIR in $TLSCERTS; do
        for OBJ in `find $FILEORDIR`; do
            ACLOUT=`getfacl --skip-base $OBJ 2>/dev/null`
            if [ "$ACLOUT" != "" ]; then
                setfacl --remove-all $OBJ
            fi
        done
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008220: LDAP TLS Certificate Ownership'
    TLSCERTS=$(  grep -i '^tls_cert' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSCERTS; do
        if [ -a $TLSCERTS ]; then
            CUROWN=`stat -c %U $TLSCERTS`;
            if [ "$CUROWN" != "root" ]; then
                chown -R root $TLSCERTS
            fi
        fi
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008240: LDAP TLS Certificate Group'
    echo '                     Ownership'
    TLSCERTS=$(  grep -i '^tls_cert' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSCERTS; do
        if [ -a $TLSCERTS ]; then
            CURGOWN=`stat -c %G $TLSCERTS`;
            if [ "$CURGOWN" != "root" -a "$CURGOWN" != "bin" -a "$CURGOWN" != "sys" -a "$CURGOWN" != "system" ]; then
                chgrp root $TLSCERTS
            fi
        fi
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008260: LDAP TLS Certificate Permissions'
    TLSCERTS=$(  grep -i '^tls_cert' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSCERTS; do
        if [ -a "$TLSCERTS" ]; then
            FILEPERMS=`stat -L --format='%04a' $TLSCERTS`
            FILESPECIAL=${FILEPERMS:0:1}
            FILEOWNER=${FILEPERMS:1:1}
            FILEGROUP=${FILEPERMS:2:1}
            FILEOTHER=${FILEPERMS:3:1}
            if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&3)) != "0" ] || [ $(($FILEOTHER&3)) != "0" ]; then
                chmod u-xs,g-wxs,o-wxt $TLSCERTS
            fi
        fi
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008300: LDAP TLS Key Ownership'
    TLSKEY=$(  grep -i '^tls_key' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSKEY; do
        if [ -a $TLSKEY ]; then
            CUROWN=`stat -c %U $TLSKEY`;
            if [ "$CUROWN" != "root" ]; then
                chown root $TLSKEY
            fi
        fi
    done
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Patching GEN008320: LDAP TLS Key Group Ownership'
    TLSKEY=$(  grep -i '^tls_key' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSKEY; do
        if [ -a $TLSKEY ]; then
            CURGOWN=`stat -c %G $TLSKEY`;
            if [ "$CURGOWN" != "root" ]; then
                chgrp root $TLSKEY
            fi
        fi
    done
fi
sysv-rc-conf --list iptables | grep ':on' > /dev/null
if [ $? -ne 0 ]; then
    echo ' Patching GEN008520: Enable iptables Firewall '
    sysv-rc-conf iptables on &> /dev/null
    service iptables start &>/dev/null
fi
grep '^\-A INPUT' /etc/sysconfig/iptables | tail -n 1 | egrep '\-A INPUT \-j REJECT \-\-reject-with icmp-host-prohibited' > /dev/null
if [ $? -ne 0 ]; then
    echo ' Patching GEN008540: Disable All Traffic Not '
    echo '                     Explicity Allowed by iptables'
    iptables -A INPUT -j REJECT --reject-with icmp-host-prohibited > /dev/null
    service iptables save &>/dev/null
fi
if [ -a "/boot/grub/grub.conf" ]; then
echo ' Patching GEN008720: grub.conf Permissions'
    FILEPERMS=`stat -L --format='%04a' /boot/grub/grub.conf`
    FILESPECIAL=${FILEPERMS:0:1}
    FILEOWNER=${FILEPERMS:1:1}
    FILEGROUP=${FILEPERMS:2:1}
    FILEOTHER=${FILEPERMS:3:1}
    if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&7)) != "0" ] || [ $(($FILEOTHER&7)) != "0" ]; then
        chmod u-xs,g-rwxs,o-rwxt /boot/grub/grub.conf
    fi
fi
if [ -a "/boot/grub/grub.conf" ]; then
    echo ' Patching GEN008760: grub.conf Ownership '
    CUROWN=`stat -c %U /boot/grub/grub.conf`;
    if [ "$CUROWN" != "root" ]; then
        chown root /boot/grub/grub.conf
    fi
fi
if [ -a "/boot/grub/grub.conf" ]; then
    echo ' Patching GEN008780: grub.conf Group Ownership'
    CURGROUP=`stat -c %G /boot/grub/grub.conf`;
    if [  "$CURGROUP" != "root" -a "$CURGROUP" != "bin" -a "$CURGROUP" != "sys" -a "$CURGROUP" != "system" ]; then
        chgrp root /boot/grub/grub.conf
    fi
fi
if [ -e /etc/ldap.conf ]; then
    echo ' Remediation: LDAP TLS Key Permissions'
    TLSKEY=$(  grep -i '^tls_key' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSKEY; do
        if [ -a $TLSKEY ]; then
            FILEPERMS=`stat -L --format='%04a' $TLSKEY`
            FILESPECIAL=${FILEPERMS:0:1}
            FILEOWNER=${FILEPERMS:1:1}
            FILEGROUP=${FILEPERMS:2:1}
            FILEOTHER=${FILEPERMS:3:1}
            if [ $(($FILESPECIAL&7)) != "0" ] || [ $(($FILEOWNER&1)) != "0" ] || [ $(($FILEGROUP&7)) != "0" ] || [ $(($FILEOTHER&7)) != "0" ]; then
                chmod u-x,g-rwxs,o-rwxt $TLSKEY
            fi
        fi
    done
fi

echo ' Remediation: Remove ACLs from Library Files'
for LIBDIR in /usr/lib /usr/lib64 /lib /lib64; do
  if [ -d $LIBDIR ]; then
    for LIBFILE in `find $LIBDIR -type f \( -name *.so* -o -name *.a* \)`; do
      ACLOUT=`getfacl --skip-base $LIBFILE 2>/dev/null`;
      if [ "$ACLOUT" != "" ]; then
        setfacl --remove-all $LIBFILE
      fi
    done
  fi
done
echo ' Checking LNX001476: Password Hashes in gshadow'
BADHASH=`awk -F ':' '{ if($2 != "x" && $2 != "*" && $2 != "!" && $2 != "!!" && $2 != "") print $1 }' /etc/gshadow | tr "\n" " "`
if [ "$BADHASH" != "" ]; then
    echo "------------------------------"
    echo
    echo "${BADHASH}"
    echo
    echo "------------------------------"
fi
echo ' Patching LNX00220: Set lilo.conf permissions'
if [ -f /etc/lilo.conf ]; then
    chmod 600 /etc/lilo.conf
fi
echo ' Patching LNX00340: Disable unnecessary accounts.'
/usr/sbin/userdel news
/usr/sbin/userdel operator
/usr/sbin/userdel games
/usr/sbin/userdel gopher
/usr/sbin/userdel nfsnobody
/usr/sbin/userdel ftp
echo ' Patching LNX00360: Set X server options'
grep -q Standard /etc/gdm/custom.conf &>/dev/null
    if [ $? -ne 0 ]; then
        cat >> /etc/gdm/custom.conf << EOF
[server-Standard]
name=Standard server
command=/usr/bin/Xorg -br -audit 4 -s 15
flexible=true
EOF
fi
echo ' Patching LNX00420: Set access.conf group owner'
chgrp root /etc/security/access.conf
echo ' Patching LNX00500: Set sysctl.conf group owner'
chgrp root /etc/sysctl.conf
echo ' Patching LNX00600: Console Permissions'
find /etc/pam.d/ -type f | xargs sed -i '/pam_console.so/d'
if [ -a "/etc/security/console.perms" ]; then
    rm -f /etc/security/console.perms
fi
find /etc/security/console.perms.d/ -type f -name '*.perms' -exec rm -f {} \;
echo ' Remediating: Add mesg -n to global'
echo '                     initialization files'
for FILE in /etc/{profile,bashrc}; do
    `/bin/grep -q mesg $FILE`
    if [ $? -gt 0 ]; then
        echo "mesg n" >> $FILE
    fi
done;
echo ' Remediating: Remove ACLs from Home Directories'
ACLHOMEDIR=$(cut -d : -f 6 /etc/passwd | xargs -n1 ls -ld |grep '+' | awk '{print $9}')
for DIR in $ACLHOMEDIR; do
    if [ -d $DIR ]; then
            setfacl --remove-all $DIR
    fi
done
echo ' Patching V-38627: Remove openldap-servers Package'
apt-get -y purge telnet-server
apt-get -y purge tftp-server
if [ -e /etc/ldap.conf ]; then
    echo ' Remediating: Remove ACLs from LDAP TLS Key'
    TLSKEY=$(  grep -i '^tls_key' /etc/ldap.conf | awk '{print $2}' )
    for line in $TLSKEY; do
        if [ -a $TLSKEY ]; then
            ACLOUT=`getfacl --skip-base $TLSKEY 2>/dev/null`;
            if [ "$ACLOUT" != "" ]; then
                setfacl --remove-all $TLSKEY
            fi
        fi
    done
fi
echo ' Patching V-38584: Remove xinetd Package'
apt-get- y purge xinted ypserv
egrep 'GSSAPIAuthentication.*yes' /etc/ssh/ssh_config > /dev/null
    if [ $? -eq 0 ]; then
        sed -i "/GSSAPIAuthentication/ c\GSSAPIAuthentication no" /etc/ssh/ssh_config
    fi
else
    echo "GSSAPIAuthentication no" >> /etc/ssh/ssh_config
fi
if [ `grep -c "^KerberosAuthentication" /etc/ssh/sshd_config` -gt 0 ]; then
    egrep '^KerberosAuthentication.*yes' /etc/ssh/sshd_config > /dev/null
    if [ $? -eq 0 ]; then
        sed -i "/^KerberosAuthentication/ c\KerberosAuthentication no" /etc/ssh/sshd_config
        service sshd restart &>/dev/null
    fi
else
    echo "KerberosAuthentication no" >> /etc/ssh/sshd_config
    service sshd restart &>/dev/null
fi
if [ `grep -c "^GSSAPIAuthentication" /etc/ssh/sshd_config` -gt 0 ]; then
    egrep '^GSSAPIAuthentication.*yes' /etc/ssh/sshd_config > /dev/null
    if [ $? -eq 0 ]; then
        sed -i "/^GSSAPIAuthentication/ c\GSSAPIAuthentication no" /etc/ssh/sshd_config
        service sshd restart &>/dev/null
    fi
else
    echo "GSSAPIAuthentication no" >> /etc/ssh/sshd_config
    service sshd restarat &>/dev/null
fi
grep INACTIVE=-1 /etc/default/useradd > /dev/null
if [ $? -eq 0 ]; then
    sed -i -e 's/INACTIVE=-1/INACTIVE=35/g' /etc/default/useradd
fi
