#!/usr/bin/env bash

echo "2. Authentication"

cp -f data/login.defs /etc/login.defs

echo 'Configuring PAM!'

cp -Rf /etc/pam.d data/pam.d-img

cp -Rf data/pam.d /etc/pam.d

read -p "Note down PAM points, if any, and then press enter to continue to reset PAM"

cp -Rf data/pam.d-img /etc/pam.d

echo "Configuring LightDM"

# Debug, does this work?

for lightdmfile in $(ls /usr/share/lightdm/lightdm.conf.d/); do

  echo "[SeatDefaults]" > /usr/share/lightdm/lightdm.conf.d/$lightdmfile

  echo "greeter-wrapper=/usr/lib/lightdm/lightdm-greeter-session" >> /usr/share/lightdm/lightdm.conf.d/$lightdmfile

  echo "user-session=ubuntu" >> /usr/share/lightdm/lightdm.conf.d/$lightdmfile

  echo "allow-guest=false" >> /usr/share/lightdm/lightdm.conf.d/$lightdmfile

  echo "greeter-hide-users=true" >> /usr/share/lightdm/lightdm.conf.d/$lightdmfile

  echo "greeter-show-manual-login=true" >> /usr/share/lightdm/lightdm.conf.d/$lightdmfile

  echo "greeter-show-remote-login=false" >> /usr/share/lightdm/lightdm.conf.d/$lightdmfile

done

echo "Setting SSL and TLS preferences..."

echo "ssl start_tls" > /etc/pam_ldap.conf

echo -e "tls_cacertdir /etc/pki/tls/CA\ntls_cacertfile /etc/pki/tls/CA/cacert.pem" >> /etc/pam_ldap.conf

echo "3. Login/Screensaver Configuration"

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type int --set /apps/gnome-screensaver/idle_delay 15

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gnome-screensaver/idle_activation_enabled true

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gnome-screensaver/lock_enabled true

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gdm/simple-greeter/banner_message_enable true

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type bool --set /apps/gdm/simple-greeter/disable_user_list true

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type string --set /apps/gnome-screensaver/mode blank-only

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type string --set /apps/gnome_settings_daemon/keybindings/screensaver "<Control><Alt>l"

gconftool-2 --direct --config-source xml:readwrite:/etc/gconf/gconf.xml.mandatory --type string --set /apps/gdm/simple-greeter/banner_message_text "I've read & consent to terms in IS user agreem't."

echo "Check Listening Network Ports/Processes"

echo "NMAPping..."

nmap -v -sT localhost

read -p ''

echo "LSOFing..."

lsof -i

read -p "Take note of bad stuff... "

service cron restart

echo "InitiallyPowered = False" > /etc/bluetooth/main.conf

echo "4. Setting Firewall rules…"

echo "IPv6=no" >> /etc/default/ufw

cp -f data/before.rules /etc/ufw/before.rules

iptables -A FORWARD -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s -j ACCEPT

echo "ALL: ALL" > /etc/hosts.deny

echo "5. Checking sudo config stuff now..."

sudo egrep -i '(nopasswd|!authenticate)' /etc/sudoers /etc/sudoers.d/*

read -p "If there was an output, please note it down and FIX IT dumy pugy"

echo "6. Media Files"

find / -iname '*.mp3' -type f -delete

read -p "Please do manual inspection of home directory just in case."

echo "7. Kernel Security"

cp -f data/sysctl.conf /etc/sysctl.conf

sysctl -e -p > /dev/null

function fs_disable {

  local FS

  FS="appletalk sctp dccp ddcp_ipv4 dccp_ipv6 rds tipc cramfs freevxfs jffs2 hfs hfsplus squashfs udf vfat"

  log_info "Disabling filesystems ${FS[@]}"

  for disable in $FS; do

      echo "install $disable /bin/true" >> "/etc/modprobe.d/${disable}.conf"

  done

}

echo "install usb-storage /bin/true" >> /etc/modprobe.d/usb-storage.conf

echo "install uas /bin/true" >> /etc/modprobe.d/usb-storage.conf

echo "install net-pf-31 /bin/true" >> /etc/modprobe.d/bluetooth.conf

echo "install bluetooth /bin/true" >> /etc/modprobe.d/bluetooth.conf

echo "install appletalk /bin/true" >> /etc/modprobe.conf

echo "install sctp /bin/true" >> /etc/modprobe.conf

echo "install dccp /bin/true" >> /etc/modprobe.conf

echo "install dccp_ipv4 /bin/true" >> /etc/modprobe.conf

echo "install dccp_ipv6 /bin/true" >> /etc/modprobe.conf

echo "install rds /bin/true" >> /etc/modprobe.conf

echo "install tipc /bin/true" >> /etc/modprobe.conf

echo "8. Review Inittab and Boot Scripts"

cp -f data/control-alt-delete.conf /etc/init/control-alt-delete.conf

echo 'exec /usr/bin/logger -p security.info "Ctrl-Alt-Delete pressed"' > /etc/init/control-alt-delete.override

touch /etc/inittab

echo "id:3:initdefault:" > /etc/inittab

echo "9. Secure Browser"

read -p "Refresh Firefox! (https://bit.ly/2Ql6OLP)"

echo "10. Secure Console"

echo "tty1" > /etc/securetty

echo "11. Secure /tmp"

dd if=/dev/zero of=/usr/tmpDISK bs=1024 count=2048000

mkdir /tmpbackup

cp -Rpf /tmp /tmpbackup

mount -t tmpfs -o loop,noexec,nosuid,rw /usr/tmpDISK /tmp

chmod 1777 /tmp

cp -Rpf /tmpbackup/* /tmp/

rm -rf /tmpbackup

echo "/usr/tmpDISK  /tmp    tmpfs   loop,nosuid,nodev,noexec,rw  0 0" >> /etc/fstab

sudo mount -o remount /tmp

rm -rf /var/tmp

ln -s /tmp /var/tmp

echo "12. Secure services"

read -p "Make sure kro-1 is finished by now"

#aide

echo "SILENTREPORTS=no" >> /etc/default/aide

echo "MAILTO=root" >> /etc/default/aide

echo "/usr/sbin/auditctl p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/auditd p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/ausearch p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/aureport p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/autrace p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/audispd p+i+n+u+g+s+b+acl+xattr+sha512
/usr/sbin/augenrules p+i+n+u+g+s+b+acl+xattr+sha512" >> /etc/aide/aide.conf

sudo aideinit

mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db

sudo aide --init

echo "05 4 * * * root /usr/sbin/aide --check" >> /etc/crontab

#psad

echo "ENABLE_AUTO_IDS Y" >> /etc/psad/psad.conf

sudo iptables -A INPUT -j LOG

sudo iptables -A FORWARD -j LOG

sudo ip6tables -A INPUT -j LOG

sudo ip6tables -A FORWARD -j LOG

sudo iptables -P INPUT DROP

sudo ip6tables -P INPUT DROP

sudo psad -R

sudo psad --sig-update

sudo psad -H

#apt

echo "Unattended-Upgrade::Remove-Unused-Dependencies "true";" >> /etc/apt/apt.conf.d/50unattended-upgrades

#fail2ban

sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

echo "[ssh]
enabled = true
port = 222
filter = sshd
logpath = /var/log/auth.log
maxretry = 2
[ssh-ddos]
enabled = true
port = 222
filter = sshd-ddos
logpath = /var/log/auth.log
maxretry = 2" >> /etc/fail2ban/jail.local

#auditd

cp -f data/audit.rules /etc/audit/audit.rules

cp -f data/auditd.conf /etc/audit/auditd.conf

chmod 0640 /etc/audit/auditd.conf && chown root /etc/audit/auditd.conf && chgrp root /etc/audit/auditd.conf && chmod go-w /etc/audit/auditd.conf

auditdctl -e 1

echo "13. SysFile SEC"

find / -iname "*.equiv" -delete

find / -iname "*.rhosts" -delete

find / -iname "*.perms" -delete

cp -f data/useradd /etc/default/useradd

cp -f data/ntp.conf /etc/ntp.conf

cp -f data/access.conf /etc/security/access.conf

cp -f data/shells /etc/shells

cp -f data/.profile ~/.profile

cp -f data/.profile /etc/profile

echo "umask 077" > /etc/csh.cshrc

echo "umask 022" >> /lib/lsb/init-functions

cp -f data/limits.conf /etc/security/limits.conf

for bashfile in `find / -name "*.bashrc"`; do cp -f data/bashrc $bashfile; done

echo "NEXT STEPS"

echo " - Check Hosts File"

echo " - Check Services"

echo " - Check Critical Services (kro-3.sh)"

echo " - Check Aliases"

echo " - Check .bashrc"