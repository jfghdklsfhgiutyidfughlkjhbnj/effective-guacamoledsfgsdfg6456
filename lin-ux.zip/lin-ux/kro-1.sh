#!/usr/bin/env bash

echo -e 'APT::Periodic::Update-Package-Lists "1";\nAPT::Periodic::Download-Upgradeable-Packages "1";\nAPT::Periodic::AutocleanInterval "7";\nAPT::Periodic::Unattended-Upgrade "1";' >> /etc/apt/apt.conf.d/20auto-upgrades

echo -e 'APT::Periodic::Update-Package-Lists "1";\nAPT::Periodic::Download-Upgradeable-Packages "1";\nAPT::Periodic::AutocleanInterval "7";\nAPT::Periodic::Unattended-Upgrade "1";' >> /etc/apt/apt.conf.d/10periodic

# add sources noW!!

sudo cp -f data/sources.list /etc/apt/sources.list

read -p "BEFORE YOU START: Please check Software Management for Daily Updates and UPDATE SOURCES!"

echo "1. Software Management and Updates"

cp -f data/initial-status.gz /var/log/installer/initial-status.gz

echo "These are the manually installed packages: "

comm -23 <(apt-mark showmanual | sort -u) <(gzip -dc /var/log/installer/initial-status.gz | sed -n 's/^Package: //p' | sort -u)

read -p "Which packages would you like to remove? Please separate each with a space. " badpkgs

sudo apt-get purge $badpkgs

echo "Now removing risky default packages... "

sudo apt-get purge telnet* samba* transmission* xinetd*

echo "Now installing apt-fast... "

sudo add-apt-repository ppa:apt-fast/stable

sudo apt-get -y update

sudo apt-get -y install apt-fast

echo "Now installing reccomended security packages... "

sudo apt-fast -y install debsums debsecan fail2ban clamav rkhunter auditd audispd-plugins psad aide acct libpam-cracklib ansible sysv-rc-conf chkrootkit

echo "Now updating and upgrading system, and start kro-2! "

read -p ''

sudo apt-fast -y update

sudo apt-fast -y upgrade

sudo apt-fast -y dist-upgrade
