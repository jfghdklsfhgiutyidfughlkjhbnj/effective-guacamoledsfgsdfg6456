#!/usr/bin/env bash

run_samba() {
  sudo apt-fast install samba
  read -p "If there is previous config exit this and cp to the end"
  cp -f data/smb.conf /etc/samba/smb.conf
  sysv-rc-conf samba on && service samba start
  sudo sysv-rc-conf nmbd.service off
}

run_ssh() {
  sudo apt-fast install ssh openssh-server
  cp -f data/sshd_config /etc/ssh/sshd_config
  echo "sshd: ALL" >> /etc/hosts.allow
  cd ~/.ssh
  ssh-keygen -t rsa
}

run_ftp() {
  sudo apt-fast install vsftpd
  cp -f data/vsftpd.conf /etc/vsftpd.conf
  echo "vsftpd: ALL" >> /etc/hosts.allow
  iptables -I INPUT -p tcp --dport 64000:65535 -j ACCEPT
  ufw allow 21/tcp
}

run_lamp () {
  sudo apt-fast install tasksel
  tasksel install lamp-server
  apt-fast install libapache2-modsecurity libapache2-mod-qos
  sudo a2dismod mpm_event
  sudo a2enmod mpm_prefork
  sudo a2enmod ssl headers rewrite
  cat data/apache-extra >> /etc/apache2/apache2.conf
  mysql_secure_installation
  cp -f data/my.cnf /etc/mysql/my.cnf
  sudo apt-fast install php-pear php5-mysql
  sudo mkdir /var/log/php
  sudo chown www-data /var/log/php
  cp -f data/php.ini /etc/php5/apache2/php.ini
  cp -f data/php.ini /etc/php5/cli/php.ini
}


printf 'What are the critical services? (samba, ssh, ftp, lamp)'
read DISTR

case $DISTR in
     samba)
          run_samba
          ;;
     ssh)
          run_ssh
          ;;
     ftp)
          run_ftp
          ;;
     lamp)
          run_lamp
          ;;
     *)
          echo "try again u little gup"
          ;;
esac
