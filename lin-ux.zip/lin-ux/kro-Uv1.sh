#!/usr/bin/env bash

#add auth users
for usr in $(cat users | cut -f1 -d":"); do useradd $usr 2> /dev/null; done
#add auth sudoers
for sudousr in $(cat users | grep sudoer | cut -f1 -d":"); do adduser $sudousr sudo 2> /dev/null; done
#remove unauth sudoer
for nosudousr in $(cat users | grep nosudo | cut -f1 -d":"); do deluser $nosudousr sudo 2> /dev/null; done
#change all passwords to "CyberSec123!"
cat /etc/passwd | cut -f1 -d":" > /tmp/userpwd
for i in $(cat /tmp/userpwd); do
    echo $i:CyberSec123! | chpasswd
    usermod -s /bin/false $i
done

usermod -s /bin/bash root

cat /etc/passwd > passwd
sed -i '/root:x/d' passwd
sed -i '/daemon:x/d' passwd
sed -i '/bin:x/d' passwd
sed -i '/sys:x/d' passwd
sed -i '/sync:x/d' passwd
sed -i '/games:x/d' passwd
sed -i '/man:x/d' passwd
sed -i '/lp:x/d' passwd
sed -i '/mail:x/d' passwd
sed -i '/news:x/d' passwd
sed -i '/uucp:x/d' passwd
sed -i '/proxy:x/d' passwd
sed -i '/www-data:x/d' passwd
sed -i '/backup:x/d' passwd
sed -i '/list:x/d' passwd
sed -i '/irc:x/d' passwd
sed -i '/gnats:x/d' passwd
sed -i '/nobody:x/d' passwd
sed -i '/libuuid:x/d' passwd
sed -i '/syslog:x/d' passwd
sed -i '/messagebus:x/d' passwd
sed -i '/usbmux:x/d' passwd
sed -i '/dnsmasq:x/d' passwd
sed -i '/avahi-autoipd:x/d' passwd
sed -i '/kernoops:x/d' passwd
sed -i '/rtkit:x/d' passwd
sed -i '/saned:x/d' passwd
sed -i '/whoopsie:x/d' passwd
sed -i '/speech-dispatcher:x/d' passwd
sed -i '/avahi:x/d' passwd
sed -i '/lightdm:x/d' passwd
sed -i '/colord:x/d' passwd
sed -i '/hplip:x/d' passwd
sed -i '/pulse:x/d' passwd

for urmomgup in $(cat users | cut -f1 -d":"); do usermod -s /bin/bash $urmomgup; done

for goodgups in $(cat users | cut -f1 -d":"); do sed -i "/$goodgups/d" passwd; done

cat passwd